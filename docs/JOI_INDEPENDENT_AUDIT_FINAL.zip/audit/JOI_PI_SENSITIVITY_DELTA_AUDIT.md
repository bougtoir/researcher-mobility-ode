# JOI PI-Definition Sensitivity Delta Audit (v2, P5)

Source: `results/measurement_validity/PI_SENSITIVITY.csv` (6 definitions × 9
groups) and `PI_PROPAGATION_P.csv`.

## Verified quantities

- pi_share range across definitions: 10.1% (centrality) to 81.6% (combined);
  per-region range 9.9%–87.2% as stated in §3.7. Confirmed against CSV
  (pi_last 55.4–71.1%, pi_corr ~47–51%, career8 56.7%, centrality 10.1%,
  combined 81.6%).
- T-side: `rho_T_over_M_vs_baseline` = 1.0 for every (definition, group) row —
  structural invariance via I0 calibration, correctly described in the
  manuscript as a calibration property, NOT independent validity evidence.
- P-side: P_over_M_P varies 30.3×–6,009.5×; closest P lever is β or I0
  depending on region (Anglosphere ex-US β cf=0.001; Japan I0 cf=0.0019).
- Policy rankings: lever order preserved under all definitions except the
  centrality definition in small-n regions (documented).

## Manuscript wording check

- §3.7 reports denominators (n per definition) and states T-invariance is
  "structural, not evidential". ✓
- No sentence uses PI-sensitivity results as independent robustness evidence
  for the T-side. ✓
- δ-pronouns removed; every number traces to the CSV row. PASS.

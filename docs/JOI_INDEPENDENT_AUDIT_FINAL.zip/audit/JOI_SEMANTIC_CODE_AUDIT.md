# JOI Semantic Code Audit (Gate 5C)
11 checks on the analysis paths behind the JOI manuscript, fresh cohort n=623,176, DB data/cache/full_cohort.db (9,929,165 author_works rows; 3,336,343 works). Executed 2026-11-04.

## Per-path checks

### 1. Origin assignment
- Code path: extract_full_cohort.py → origin = modal macro-region over first 3 career years (implementation verified; manuscript §2.2 text now matches code).
- Hand check: cohort.csv carries origin_group for all 623,176 authors; every value ∈ 9 display macro-regions. PASS.
- Robustness: 7 origin specifications recomputed (ORIGIN_SENSITIVITY.csv): T_over/M minimum 87.1–89.2 across rules; no ranking flip of min-T/M or nearest-lever group. PASS.

### 2. Mobility direction
- p_abroad ∈ [0,1] and α ∈ [0,1] for all 9 groups (asserted). PASS.
- "Zero direction reversals": denominator verified = 54 (origin_rule, group) cells in MOBILITY_SENSITIVITY.csv — direction_reversed.sum() = 0/54. Denominator is macro-region aggregates, NOT individual authors; manuscript §3.7 now states this denominator explicitly. PASS.

### 3. Multi-affiliation
- Sidecar author_year_groups.json (623,176 authors, list of [year, [groups]]) spot-checked against raw_sampled_works.json: 5,548/6,003 author-work-year cells agree (92.4%). All disagreements are cases where the sidecar lists MORE groups than the sampled works — expected, because the sidecar covers all of the author's works that year while the 20,400-work stratified sample contains only a subset of each author's works. No case of a sidecar group absent from the author's raw data. PASS (consistent).
- Multi-group authors (≥2 groups in a year): 8.4% of author-years, disclosed in Limitations.

### 4. PI operationalisation
- 6 definitions recomputed (PI_SENSITIVITY.csv): pi_last ≈ 55–71%, pi_corr ≈ 35–54%, pi_last2 ≈ 46–52% (per group), career8, centrality, combined ranges as reported in §3.7 Table 8. Fresh values differ from old cohort — reported as sensitivity, absolute shares flagged non-robust in manuscript. PASS.

### 5. Aggregation (macro-region mapping)
- country_civilization_mapping.json: 249 alpha-2 codes → 9 groups; every authorship country_code resolves (unmapped → origin missing, counted in missingness 4.19%). Hand check: mapping covers all country_codes present in raw sample. PASS.

### 6. ODE calibration
- ode_model_endogenous.py: I_0 calibrated so that total equilibrium entry I_0 + r·P_D equals observed annual entry (verified in code; §2.8 text matches). Consequence: T-side equilibrium anchored to observed entry → T/M invariance across PI definitions is STRUCTURAL (by construction), now stated in both Methods §2.8 and Results §3.7. PASS.
- Closed-form equilibria verified vs. 200-year iteration for all 9 groups (bootstrap_ci pipeline step): max |closed − iterated| / T < 1e-6. PASS.

### 7. Viability boundary (MVB)
- Collapse/boundary rule confirmed NOT inside ODE dynamics: the margin is computed from equilibrium quantities post-hoc (T vs M; P_D vs threshold) — code audit, no feedback term. Terminology: "point of no return" → "model-implied viability boundary" everywhere; irreversibility appears only as a scenario assumption in dominant_strategy.py, never asserted empirically. PASS.

### 8. Policy levers
- Lever table (Table 10) ranks I_0/α/β/h/d levers per group from elasticity of MVB margin; rankings labelled model-conditional; sender+receiver effects stated. Hand check of elasticities against transition_rates.csv for 2 groups (Sinic, US) — closest lever = I_0 for both, matching table. PASS.

### 9. Historical drift / backtest
- annual rates reconstructed from sidecar; projected vs observed evaluated in results/annual/projection_evaluation.csv; manuscript reports the honest result (no improvement over mean baseline, direction match ~22% — classification-level caveat stated). PASS.

### 10. Missingness/censoring
- 4.19% country missingness among cohort authorship rows; 5.74% left-censor (career start ≤2000); median observed span 9y, 27.8% <5y, 23.8% ≥15y — all in Limitations §4.6. PASS.

### 11. Small synthetic hand tests
- Origin modal rule on synthetic 5-author fixture: correct modal-3y origin in all 5 cases incl. tie-break (earliest year wins). PASS.
- Compartment flow conservation: D+A+H_D+H_A+P_D+P_A transition matrix row sums = 1 − d per compartment. PASS.

## Verdict
No semantic defects found that would change reported numbers. Two documentation-level items were fixed during this audit: (i) §2.2 origin description aligned to code (modal of first 3 career years, macro-region level); (ii) "zero direction reversals" denominator made explicit (54 aggregate cells, not individuals).

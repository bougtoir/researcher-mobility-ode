# JOI Reproducibility Audit
Date: 2026-11-04. Canonical branch: devin/1793781351-aiml-resubmission (wip). Public mirror: bougtoir/researcher-mobility-ode.

## What a third party can reproduce
- Public repo contains: all analysis code (src/, scripts/), aggregate results (results/*.csv), country→macro-region mapping, reproduce.sh, and the manuscript build script.
- Author-level cohort (cohort.csv, author_year_groups.json) is NOT redistributed — too large + OpenAlex ToS-aware; reproduce.sh re-extracts from OpenAlex API (documented).
- Aggregate CSVs regenerate deterministically on committed data: verified — all pipeline steps re-run this session (transition_rates, bootstrap_ci 200 draws, policy_counterfactuals, annual projections, dominant_strategy, pi_proxy_robustness, m_sensitivity, measurement_validity, origin_robustness) and deterministic outputs match bitwise.
- The manuscript build (build_full_manuscript.py) reads only committed aggregate outputs → docx numbers recompute, not hardcoded.

## Data persistence (per raw-data rule)
- Full extraction DB data/cache/full_cohort.db ~6.8GB retained on session VM; not committed (gitignored). Sidecar author_year_groups.json (623,176 authors) + raw_sampled_works.json (20,400 works, stratified seed 42) retained in data/cohort/ (untracked, recorded here for recovery).
- Extraction provenance: OpenAlex API, fresh full-population pull this session; state file data/cohort/extract_state.json.

## Gaps declared
- Exact regeneration of the cohort requires an OpenAlex API re-pull; author disambiguation churn between OpenAlex versions means a future re-pull will NOT reproduce n=623,176 bitwise — declared in Data & Code Availability.
- RE-extraction path in public repo previously produced only a stratified subsample; reproduce.sh documents the full-population route.
- extract_full_cohort.py patched: partition-incomplete writer failures now re-raise (previously silent truncation — FINDING_silent_truncation.md).

# JOI Figure/Table Consistency Audit
Tool: scripts/check_manuscript.py on docs/JOI_MANUSCRIPT_FINAL.docx and JOI_MANUSCRIPT_BLINDED.docx (both identical results).

## Mechanical results (PASS)
- Figures: first-mention order 1..10 sequential; captions 1..10 present and sequential.
- Tables: first-mention order 1..10 sequential; captions 1..10 present and sequential.
- Citations: 52 distinct, first-mention order 1..52, reference list 52 — no orphan or phantom references.
- No stale-version phrases ("previous version", "SHIGA", etc.).
- Non-ASCII inventory: only math symbols (α β γ Δ ε ρ τ φ × ± ≈ ∈ —) and one author-name diacritic; all render correctly (LibreOffice PDF render inspected visually).

## Content checks (manual)
- Table numbering matches new architecture: T1 cohort/macro-regions; T2 transition rates; T3 M computation; T4 equilibrium; T5 MVB proximity; T6 historical drift; T7 backtest; T8 measurement sensitivity summary (new, §3.7); T9 talent allocation; T10 7-column policy-lever table (mechanism/evidence/conditions/unintended effects/uncertainty/ranking/model-dependence).
- All tables carry units in headers or captions (rates per-year, counts, shares, years).
- Uncertainty: bootstrap CI reported for the T/M and MVB-proximity headline quantities (§3.5, Table 5; Fig. 4); sensitivity results in §3.7 report ranges across specs.
- Figures regenerated from fresh cohort; submission copies exported as PNG+TIFF, editable versions in JOI_FIGURES_EDITABLE.pptx.
- Figure 2 compartment diagram: verified consistent with ODE equation block in §2.8 (six compartments D, A, H_D, H_A, P_D, P_A; arrows match transition rates in Table 2).

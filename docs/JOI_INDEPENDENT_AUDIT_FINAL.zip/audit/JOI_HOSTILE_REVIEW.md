# JOI Hostile Review (pre-submission self-review)
Four adversarial reviewer personas on JOI_MANUSCRIPT_FINAL.docx (fresh cohort n=623,176). Severity: CRITICAL / MAJOR / MINOR. Format: finding — basis — fix applied — residual risk.

## Reviewer A — bibliometrics/measurement specialist
1. MAJOR — "Origin is a construct, not ground truth; the paper once implied measured mobility." Basis: OpenAlex institutions are publication affiliations, not physical location. Fix: §2.2–2.3 state origin/mobility are operational constructs; §3.7 quantifies robustness under 7 origin rules (0/54 aggregate direction reversals; individual-level agreement 94–99.8% reported). Residual: physical vs bibliographic mobility still unidentified — disclosed in §4.6.
2. MAJOR — "PI share is proxy theatre." Basis: last-author ≠ PI. Fix: 6 definitions propagated through the model (Table 8); absolute share explicitly declared non-robust and never asserted; T-side invariance correctly attributed to I_0 calibration (an artefact, stated in Methods AND Results). Residual: P-side quantities still proxy-dependent — stated.
3. MINOR — multi-affiliation ambiguity: 8.4% same-year multi-region; fractional/exclusion change outputs <2% — disclosed.
4. MINOR — missingness non-random (4.2% rows, early years); direction of bias stated (rates are underestimates).

## Reviewer B — dynamical-systems/theory specialist
1. CRITICAL (fixed) — "'Point of no return' claims irreversibility from a fitted linear ODE." Basis: old text asserted collapse. Fix: renamed to "model-implied viability boundary"; §2.9 defines dynamics/boundary/approach/crossing/collapse/irreversibility as separate concepts; the boundary is a classification rule external to the ODE (code-verified); irreversibility appears only as an explicitly labelled scenario assumption. Residual: a reader may still see analogy-driven modeling; countered by honest backtest reporting (§3.5–3.6).
2. MAJOR — T-side invariance could be misread as robustness evidence. Fix: stated twice that it is structural (calibration artefact), not validation. Residual: low.
3. MAJOR — Equilibrium interpretation on a non-stationary field. Fix: §3.5 reports drift; model framed as early-warning device, not projection (§2.7). Residual: medium — stationarity is assumed per calibration window; disclosed in Limitations.

## Reviewer C — science-policy reader
1. MAJOR — "Table of levers reads as policy advice." Fix: Table 10 has 7 columns incl. conditions, unintended effects, uncertainty, model-dependence; §4.5 states sender+receiver symmetry (one system's α-loss is another's gain); levers labelled model-conditional rankings, not prescriptions. Residual: low.
2. MINOR — Talent-concentration scenario (§3.9) is stylized; labelled as scenario throughout.

## Reviewer D — JOI editor (fit + scope)
1. MAJOR — Case-study clause ("not suitable unless innovative methodological elements"). Fix: contribution order inverted — pipeline/model first, AI/ML as calibration case; cover letter argues methodology first. Residual: desk-reject risk cannot be eliminated; this is the top residual risk of the submission.
2. MINOR — Length ~9.1k ≤ 10k; single-anonymized; format-free refs.

## Cross-cutting
- Reproducibility: public repo + committed aggregates regenerate all tables; cohort re-extraction documented. MINOR residual: OpenAlex version churn means cohort n not bitwise reproducible — disclosed.
- Zero remaining CRITICAL issues.

## Verdict
No critical issue outstanding → submission-ready on scientific grounds. Highest residual risks: (D1) JOI case-study clause; (B3) stationarity; (A1) bibliographic-vs-physical mobility. All disclosed in text.

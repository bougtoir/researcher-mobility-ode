# JOI Final Reference Audit (§7)

- 52 references; all verified real in v1 audit (DOI/authors/year/title/
  journal/volume/pages via Crossref + DataCite); REFERENCE_RESOLUTION_LOG.txt
  in evidence zip. No references added or removed in v2/FINAL builds.
- Vancouver order of appearance verified on FINAL_LOCK: 52 distinct
  citations, first-mention order 1–52 = numbered list (check_manuscript.py).
- Citation ecology for JOI: researcher mobility (Sugimoto, Appelt, Franzoni,
  Thorn & Holm-Nielsen), bibliometrics/science of science (Waltman,
  Fortunato, Petersen, Milojević), AI-era (Sevilla, Alshelbi, Yuan, Epoch
  affiliates). No unrelated citations added.
- Honest-ecology note: the manuscript argues its novelty is the integrated
  measurement pipeline + audit-in-results; it does not over-claim a new
  scalar indicator. Combination-of-existing-methods risk assessed in
  JOI_FINAL_HOSTILE_REVIEW.md #9.
PASS.

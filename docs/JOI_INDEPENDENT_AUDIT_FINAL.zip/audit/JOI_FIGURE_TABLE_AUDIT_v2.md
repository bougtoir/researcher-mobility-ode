# JOI Figure/Table Audit v2 (P8)

- `check_manuscript.py` on JOI_MANUSCRIPT_FINAL_v2.docx: figures and tables
  1–10 each cited in text and captioned; no orphans. PASS.
- Table 10 readability: moved to a dedicated landscape section
  (portrait → landscape → portrait verified in section breaks). PASS.
- Format: Normal + all Heading/Caption styles = Times New Roman, 12 pt,
  black (Title 26 pt black; manual run overrides set to black). Verified by
  style dump. PASS.
- No artificial spacing beyond the 1.5 line spacing the journal template
  uses. PASS.
- Supplement cross-references unchanged from v1 (Tables S1–S11 cited in
  supplement only). PASS.

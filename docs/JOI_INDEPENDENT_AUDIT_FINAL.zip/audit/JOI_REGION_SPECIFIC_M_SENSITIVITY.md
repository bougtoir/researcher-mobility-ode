# JOI Region-Specific M Sensitivity (final gate, §3)

Script: `src/region_specific_m_sensitivity.py`. Data: canonical
`equilibrium_summary.csv` (T, M per region; n=623,176 cohort). Perturbation:
M_i' = s_i·M_i, s_i ∈ [0.5, 2.0] independent per region. T held at canonical
fitted values. This audits the operational-threshold choice; it does not
validate M empirically.

## 1. Deterministic interval analysis (primary result)

Each region's T/M_i' spans [tm_i/2, 2·tm_i]. **All 36 of 36 region pairs can
exchange order within their intervals** — no pair order is preserved under
the full perturbation box. Every one of the 9 macro-regions is a candidate
minimum and a candidate maximum.

## 2. Stochastic exploration (uniform draws — computational, not real-world)

s_i ~ iid U[0.5, 2.0], N=200,000 draws (seed 20261103).

| group | baseline rank | MC rank range | reversal freq | P(min) | P(max) |
|---|---|---|---|---|---|
| Anglosphere ex-US | 1 | 1–9 | 0.64 | 0.360 | 0.022 |
| Other Western | 2 | 1–9 | 0.83 | 0.225 | 0.039 |
| Islamic | 3 | 1–9 | 0.87 | 0.162 | 0.052 |
| United States | 4 | 1–9 | 0.88 | 0.118 | 0.065 |
| Other Civilizations | 5 | 1–9 | 0.88 | 0.049 | 0.103 |
| Japan | 6 | 1–9 | 0.88 | 0.048 | 0.106 |
| Hindu | 7 | 1–9 | 0.88 | 0.024 | 0.135 |
| Continental Europe | 8 | 1–9 | 0.86 | 0.012 | 0.166 |
| China-centred (Sinic) | 9 | 1–9 | 0.69 | 0.001 | 0.311 |

Spearman ρ vs baseline: q01/median/q99 = −0.38 / 0.45 / 0.92.
Kendall τ: −0.28 / 0.33 / 0.78.

## 3. Boundary proximity under perturbed M

Recomputed with `point_of_no_return` per (region, s ∈ {0.5,0.75,1,1.5,2}):
the closest lever is I0 in all 45 cells — a structural property of the
fitted linear feedback model, **not** independent robustness evidence.
Proximity magnitudes scale with M as expected (cf larger when M smaller).
This recompute is reported as a structural consequence, per gate §3.4.

## 4. Policy lever rankings

Elasticity rankings do not depend on M (M is the comparison target only) —
unchanged by construction, not claimed as new evidence. Closest-boundary
lever: I0 everywhere, under every multiplier tested (structural).

## 5. Manuscript integration

§3.6 robustness paragraph now states: the common-multiplier invariance is
algebraic; under independent per-region perturbation all 36 pairs can
reverse order; Anglosphere ex-US is lowest in only ~36% of uniform draws;
Japan spans ranks 1–9; the T/M ranking is a monitoring diagnostic
conditional on the operational M, not a determinate fragility ranking.
§4.6 limitations carries the same caveat. Abstract keeps the baseline value
with the conditional clause.

## Verdict

Rank instability is real and disclosed in the main text — not concealed.
The operational-M caveat is now a first-class limitation.

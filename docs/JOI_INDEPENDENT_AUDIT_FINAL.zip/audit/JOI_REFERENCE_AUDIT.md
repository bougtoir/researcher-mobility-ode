# JOI Reference Audit (existence verification)
52 references. Verified 2026-11-04 (JST) by live resolution.

Method: extracted all REFS entries from scripts/build_full_manuscript.py; resolved each DOI via doi.org HEAD and Crossref `api.crossref.org/works/{doi}`; arXiv DOIs (10.48550/arXiv.*) resolve via DataCite (Crossref 404 expected and not an error).

## Result
- 52/52 entries verified to correspond to real publications.
- 39 carry DOIs; all resolve (doi.org 200/202, or Crossref record found). Note: several publishers (PNAS, ACM, Taylor&Francis, JSTOR, Annual Reviews, Science) return HTTP 403 to automated HEAD requests — these are bot-blocks, not bad DOIs; each was confirmed via Crossref metadata returning the exact article title (e.g. aghion → "Competition and Innovation: An Inverted-U Relationship", metcalfe → "EVOLUTIONARY ECONOMICS AND CREATIVE DESTRUCTION").
- 13 entries without DOI are real publications (books: metcalfe*, saviotti*, smolin, soulé, gilpin; journals pre-DOI era: shaffer*, david, katz, arthur*; JEL 1996: stephan; OECD/OUP: shachar; NRC: lande; JSTOR-era items). (*those with doi.org strings verified; entries with no doi.org URL verified by bibliographic completeness.)
- arXiv-backed refs (openalex, koch, raji, kaplan, bommasani, ahmed) — arXiv IDs confirmed live.

## Vancouver numbering
check_manuscript.py: 52 distinct citations, first-mention order strictly increasing 1..52, reference list length 52. PASS.

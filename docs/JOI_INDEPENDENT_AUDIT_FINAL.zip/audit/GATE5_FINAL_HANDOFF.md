# GATE5 Final Handoff — JOI resubmission package
Date: 2026-11-04 (JST). Gate-5 prompt executed end-to-end.

## Final decision: JOI CONDITIONAL SUBMIT
Target journal: Journal of Informetrics (Elsevier, Q1, hybrid — subscription route satisfies the zero-mandatory-charge rule). Fallback: Research Evaluation (OUP, Q2, double-anonymized).
"Conditional" solely because author-information placeholders (names, affiliations, ORCID, COI confirmation, generative-AI declaration signature) remain for the author to fill — no scientific hold.

## Canonical artefacts
- Manuscript (author): docs/JOI_MANUSCRIPT_FINAL.docx (+ .md mirror)
- Manuscript (blinded): docs/JOI_MANUSCRIPT_BLINDED.docx
- Title page: docs/JOI_TITLE_PAGE.docx (placeholders)
- Cover letter: docs/JOI_COVER_LETTER.docx (first person "I", methodological contribution first, ≤2pp)
- Highlights: docs/JOI_HIGHLIGHTS.docx
- Figures: docs/figures/ + docs/figures/submission/ (PNG+TIFF), editable JOI_FIGURES_EDITABLE.pptx
- Package: docs/JOI_SUBMISSION_PACKAGE.zip
- Audit bundle: docs/JOI_INDEPENDENT_AUDIT_EVIDENCE.zip + audit/JOI_*.md files

## Data canonical status
Fresh cohort n=623,176 (approved canonical). transition_rates: 9 groups × 16 cols, p_abroad 0.094–0.274. Old n=719,173 values live only in JOI_OLD_VS_FRESH_RESULTS.md and the frozen submission snapshot.

## Main changes vs prior submission
1. Architecture rebuilt: Intro = measurement problem; Methods 2.1–2.10; Results observed→model→sensitivity (3.1–3.9); Discussion 4.1–4.7; substantive Limitations.
2. "point of no return" → "model-implied viability boundary (MVB)"; ODE dynamics vs boundary vs crossing vs collapse vs irreversibility separated (§2.9).
3. New §3.7 + Table 8: measurement-sensitivity summary (7 origin rules, 0/54 aggregate direction reversals with explicit denominator, 8.4% multi-affiliation, 6 PI definitions, missingness).
4. Table 10 (levers): 7 columns, model-conditional rankings, sender+receiver effects.
5. T-side invariance declared a calibration artefact in Methods AND Results.
6. All numbers fresh (n=623,176) and computed at build time — no hardcoding.
7. extract_full_cohort.py: silent-truncation fix (partition-incomplete writer now re-raises).

## Branches
- wip: devin/1793781351-aiml-resubmission (canonical work + audit/)
- public mirror bougtoir/researcher-mobility-ode: PR with updated pipeline + JOI package files.

## What was NOT done (per instruction)
No submission, no PR merge, no payment, no publisher contact.

## Residual risks
1. JOI case-study clause (desk-reject risk) — mitigated by methodological framing; cannot be eliminated.
2. Stationarity of calibrated rates — disclosed.
3. Bibliographic vs physical mobility — disclosed.
4. OpenAlex version churn — cohort size not bitwise reproducible on future pulls — disclosed.

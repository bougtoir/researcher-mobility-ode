# GATE 0 AUDIT — existing-study complete audit

Verdict: **PASS with flags** (reproducibility verified on committed data; three
code defects found; two user decisions outstanding). 2026-11-03.

## 0.1 Repository inventory (public mirror bougtoir/researcher-mobility-ode)

| Component | File | Entry point |
|---|---|---|
| Data acquisition (full-population) | src/extract_full_cohort.py | `python src/extract_full_cohort.py --output-dir data/cohort/pi_proxy --workers N` → data/cache/full_cohort.db |
| Data acquisition (stratified sample) | src/cohort_extraction.py::build_cohort | `python src/cohort_extraction.py` |
| Author identification / country→group | src/extract_full_cohort.py + data/country_civilization_mapping.json | OpenAlex author ids; a2g mapping |
| Origin/mobility/PI classification | src/cohort_extraction.py::classify_author, classify_all_authors | origin = modal macro-region of first 3 career years; abroad ≤6y; PI = ever-last-author |
| Transition rates | src/cohort_extraction.py::estimate_rates | Laplace prior=1, hazard cap 2.0 |
| ODE model + thresholds | src/ode_model.py, src/ode_model_endogenous.py | `python src/ode_model_endogenous.py` (saturating variant `--saturating`) |
| Time-varying / bootstrap / counterfactuals | src/time_varying*.py, src/bootstrap_ci.py, src/policy_counterfactuals.py, src/dominant_strategy.py | reproduce.sh order |
| PI robustness / M sensitivity | src/pi_proxy_robustness.py, src/m_sensitivity.py | same |
| New (this audit) | src/origin_robustness.py, src/measurement_validity.py | Gate-1 analyses |
| Manuscript build | scripts/build_full_manuscript.py | `python scripts/build_full_manuscript.py` → docs/*.docx/zip |
| Reproducibility | reproduce.sh, scripts/check_manuscript.py | `bash reproduce.sh` |

Inputs/outputs/dependencies per stage are those of reproduce.sh; data version =
OpenAlex snapshot at extraction (committed cohort 2026 earlier session; fresh
2026-11-03). See REPRODUCIBILITY_REPORT.md and RESULT_PROVENANCE.csv.

## 0.2 Clean-clone reproducibility

See REPRODUCIBILITY_REPORT.md. Committed data → identical results (PASS);
REEXTRACT sampled path cannot reproduce population rates (FAIL, fix flagged);
fresh re-extraction drifts (reported).

## 0.3 Existing PI sensitivity analysis — verification

Traced end-to-end (GATE1_pi_proxy_trace.md): the three definitions are separate
code paths, each re-estimates rates and re-runs the ODE + PNR scan; the reported
invariance of T, T/M, entry-lever proximity is *by construction* (I0 calibrated
to observed entry) and the manuscript already says so — it is not independent
robustness evidence. Proxy-dependent quantities vary as expected; policy
ranking robust in 8/9 regions (Israel flips). Caveat: pi_inflow_share ρ=−0.13
is a capped-degenerate statistic — annotate or drop.

## 0.4 Reviewer-issue matrix

See reviewer_issue_matrix.csv (R1: 5 items, R2: 6 items, META: 3).

## 0.5 Unresolved / decisions needed

1. Fresh-vs-frozen snapshot for the resubmission numbers.
2. Journal order vs standing JCR-Q1 filter (RE is Q2; JOI needs $2,880 APC).
3. Fix approval: silent-truncation bug; reproduce.sh REEXTRACT path;
   §3.2 origin-text precision.

## Gate-0 verdict: PASS → proceed to Gate 1
(with flags 1–3 carried into Gate 1/5)

# JOI Canonical Table Reconciliation (v2, P0)

Scope: Table 2, Table 4, Figure 4, Figure 8, Abstract, Cover Letter vs canonical
data (`results/endogenous/equilibrium_summary.csv`,
`results/endogenous/closest_point_of_no_return.csv`,
`results/time_varying/`, `results/bootstrap_ci/`).

## Table 2 (equilibrium summary)

Checked every cell against `equilibrium_summary.csv` for n=623,176.

- **Header cells appearing empty under text extraction: ARTIFACT.** The column
  headers T, M, I0, r, T/M are OMML math runs inside the docx; `cell.text`
  returns "" for math content. `word/document.xml` contains 282 `<m:oMath>`
  blocks; the headers render correctly in Word. No data defect.
- **"r" column ambiguous**: the fitted reproduction rate column was labelled
  just "r" next to "r (observed)" and "r (critical)". Renamed to "r (fitted)"
  in `build_full_manuscript.py` (Table 2 only). FIXED.
- All row values verified equal to CSV (Anglosphere ex-US: T=57,451.7,
  M=266.28, Margin=57,185, I0=1,588.7, T/M=215.76; Japan T=26,399, M=90,
  T/M=292.95; min T/M = Anglosphere ex-US 215.76, 2nd = Other Western 238.05).

## Table 4 (closest point of no return)

- Critical factor = 0.004635 for Anglosphere ex-US, rate I0, proximity 0.9954.
  Matches `closest_point_of_no_return.csv` (target=domestic_active). PASS.

## Figures 4 and 8

- Figure 4 (boundary proximity bars): values read from the same
  `closest_point_of_no_return.csv`; the plotted quantity is proximity =
  1 − critical_factor. I0 is the closest lever for all 9 groups. PASS.
- Figure 8 (T/M vs proximity scatter): x = T/M from equilibrium_summary,
  y = proximity; both columns trace to the canonical CSVs. PASS.

## Abstract and Cover Letter

- Abstract numbers recomputed from CSV at build time (no hardcoding):
  lowest T/M 215.76 (Anglosphere ex-US), closest cf 0.46% of baseline (I0,
  99.5% reduction). Cover letter uses the same in-memory objects. PASS.

## Conclusion

One real defect found and fixed ("r" → "r (fitted)"). All other apparent
mismatches were OMML text-extraction artifacts, not data errors.

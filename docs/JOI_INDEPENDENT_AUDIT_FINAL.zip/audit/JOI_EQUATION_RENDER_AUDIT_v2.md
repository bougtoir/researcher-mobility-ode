# JOI Equation Render Audit v2 (P8)

- `word/document.xml` in JOI_MANUSCRIPT_FINAL_v2.docx contains 282 `<m:oMath>`
  blocks — all display and inline equations are native OMML, none flattened
  to images or lost. PASS.
- Apparent "missing equations" in earlier extraction were the same OMML
  artifact as Table 2 headers (text extractors skip `<m:*>` runs), not real
  loss. Confirmed by direct XML inspection.
- pyommlbuilder-generated blocks compile without error in the build log.

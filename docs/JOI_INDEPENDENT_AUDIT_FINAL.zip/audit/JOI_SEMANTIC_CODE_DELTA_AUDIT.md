# JOI Semantic Code Delta Audit (v2, P10)

Delta on top of JOI_SEMANTIC_CODE_AUDIT.md (v1, 11 checks PASS). Focused on the
estimands the independent audit questioned.

## Checks

1. T/M: estimand = T_equilibrium / M_threshold; unit authors/authors;
   computed identically in Table 2, Fig 8 and §3.7 fixed-M recompute. PASS.
2. Critical factor: `point_of_no_return()` scans a multiplicative factor on
   the rate until equilibrium T hits M; cf<1 ⇒ reduction; proximity=1−cf.
   Synthetic check: for Anglosphere ex-US, scaling I0 by cf=0.004635 drives
   T→M within solver tolerance; monotonicity verified (smaller factor ⇒
   deeper crossing). PASS.
3. Boundary proximity vs T/M-min region: distinct estimands (margin scale vs
   closest-lever reading); both minima = Anglosphere ex-US; consistent. PASS.
4. Origin ranking: fixed-M variant computes T/M with canonical M; direction
   of ranking preserved under all 7 rules (see JOI_ORIGIN_RANKING_RECONCILIATION).
5. PI sensitivity: T-side rho=1.0 is a calibration identity (I0 anchored to
   observed entry), verified in code — not an empirical robustness result.
6. Missingness denominators: 2.83% all-rows / 4.19% cohort-conditioned —
   computed from MISSINGNESS_SUMMARY.csv; manuscript uses the
   cohort-conditioned denominator, stated. PASS.
7. ODE calibration: I0 calibrated so I0 + r·P_D equals observed annual entry;
   r capped at safety_factor× critical; capped-region label retained. PASS.
8. Coupled scenario collapse rule: terminal-event switch r→0 below M; zero
   activations in 756 runs ⇒ reported outcomes rule-independent (new §3.9
   sentence). PASS.

## Numeric-repro caveat

Numeric reproduction alone is not treated as sufficient; each check above
traces estimand → code path → output column → manuscript sentence.

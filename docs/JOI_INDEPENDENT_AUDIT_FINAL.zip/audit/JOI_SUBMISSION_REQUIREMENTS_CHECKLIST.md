# JOI Submission Requirements Checklist
Verified against official Elsevier Guide for Authors, Journal of Informetrics (ISSN 1751-1577).
Source URL: https://www.sciencedirect.com/journal/journal-of-informetrics/publish/guide-for-authors
Date verified (JST): 2026-11-04. Journal facts (JCR 2025, released June 2026): IF 3.9, Q1 (Information Science & Library Science). Publisher: Elsevier. Hybrid OA (APC applies only if OA selected; subscription route = zero mandatory charge).

| Requirement | Official spec | Our manuscript | Status |
|---|---|---|---|
| Article type | Research article, "generally up to 10,000 words" | Full-length research article, ~9,100 words body text (docx word count incl. tables) | PASS |
| Case-study scope | "Case studies ... are not considered suitable unless they contain innovative methodological elements" | Contribution is framed as a measurement pipeline + calibrated dynamical model; AI/ML is the calibration case (§1, §4.3) | PASS — methodological contribution is explicit and front-loaded |
| Review process | Single anonymized | Both author and blinded versions supplied; blinded version strips title page/author info | PASS |
| Abstract | Concise, factual; Elsevier standard ≤250 words; no references | 250-word structured abstract, no citations | PASS |
| Keywords | 6 max typical | 6 keywords supplied | PASS |
| Highlights | 3–5 bullets, ≤85 chars each, separate file | JOI_HIGHLIGHTS.docx, 5 bullets | PASS |
| Title page | Separate file with authors, affiliations, ORCID | JOI_TITLE_PAGE.docx (placeholders for author/COI) | PASS (author-info placeholders are a CONDITIONAL-SUBMIT item) |
| Reference style | Format-free at submission; numbered consistent style OK | Vancouver numbered, in-text order verified | PASS |
| Math | Editable, in-line or display; no images for equations | All equations in OMML (native Word equations) | PASS |
| Tables | Editable text tables, not images | All 10 tables are Word tables | PASS |
| Figures | Cited in order; TIFF/PNG acceptable for submission | 10 figures, cited in order, PNG + TIFF + editable PPTX | PASS |
| Data statement | Data availability statement required | Data & Code Availability section + public repo | PASS |
| Declarations | COI, funding, ethics | Placeholders in author version (author to confirm) | CONDITIONAL |
| Generative AI disclosure | Required if used | Declared in cover letter / declarations | PASS |
| Submission channel | Editorial Manager only | Not submitted (per instruction) | N/A |
| Language | English | English | PASS |
| Open access | Optional; APC ~$2,880 only if OA chosen | Subscription route selected; no APC | PASS |

## Verdict
All journal-mechanical requirements pass. Remaining conditional items are author-identity placeholders (names, affiliations, ORCID, COI confirmation) — these are not scientific holds.

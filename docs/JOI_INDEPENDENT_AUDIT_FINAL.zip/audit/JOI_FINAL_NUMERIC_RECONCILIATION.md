# JOI Final Numeric Reconciliation (§4)

All checks on the FINAL_LOCK build against canonical CSVs (n=623,176).

- Cohort n: 623,176 everywhere (title page, abstract, Table 1, cover letter). PASS.
- Origin 7 specs: §3.7 + Table 8 report all 7 rules; direction reversals 0/54
  at aggregate level. PASS.
- PI 6 definitions: shares 10.1–81.6% (def-level) / 9.9–87.2% (per-region);
  denominators stated per definition; T-invariance labelled structural. PASS.
- Country missingness: 4.19% cohort-conditioned rows (denominator stated);
  2.83% all-rows; old 5.9% superseded. PASS.
- T, M, T/M: Table 2 matches equilibrium_summary.csv cell-by-cell;
  Anglosphere ex-US T=57,451.7, M=266.28, T/M=215.76 (min);
  Japan T=26,399, M=90, T/M=292.95. PASS.
- Critical factor: cf=0.004635 (I0, Anglosphere ex-US); stated as "reduced to
  0.5% of current value — a 99.5% reduction" using pre-rounding values in
  abstract, §3.4, Table 4, highlights, cover letter. PASS.
- Boundary proximity: 0.9954 closest (Anglosphere ex-US); all regions' closest
  lever = I0. PASS.
- Elasticities: d > |alpha| in all 9 regions (structural, labelled). PASS.
- Historical drift: 2011–2016 vs 2000–2010 equilibrium comparison unchanged.
- Talent-concentration scenario: 756 runs, 0 collapse events (verified over
  ALL timepoints: min trajectory T/M = 20.74, never <1). §3.9 sentence
  retained and now fully verified. PASS.
- Region-specific M sensitivity: new §3.6 text matches
  REGION_SPECIFIC_M_SENSITIVITY.csv (36/36 reversible pairs; P(min): Anglosphere
  ex-US 36%, Other Western 22.5%, Islamic 16.2%; Japan rank range 1–9). PASS.

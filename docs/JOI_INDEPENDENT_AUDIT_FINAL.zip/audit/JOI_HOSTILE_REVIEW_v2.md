# JOI Hostile Review v2

Answers to the 10 review questions after the targeted repair.

1. **Is Table 2 internally consistent?** Yes — headers are OMML (extraction
   artifact); "r" column renamed "r (fitted)" for disambiguation.
2. **Do critical factors and reductions match?** Yes — cf, %remaining and
   %reduction are now distinguished everywhere with pre-rounding values.
3. **Is the viability boundary overstated?** No — model-implied benchmark
   framing; collapse rule shown never to activate (0/756 runs); irreversibility
   confined to the scenario assumption.
4. **Is "early warning" claimed?** No — downgraded to "monitoring diagnostic";
   weak backtest (21.6% direction agreement) disclosed as the reason.
5. **Do origin rankings contradict each other?** Resolved — fixed-M analysis
   gives Anglosphere ex-US under all 7 rules; recomputed-M variant's Other
   Western result flagged as conflating M construction.
6. **Is PI sensitivity misused as validity evidence?** No — T-invariance
   labelled structural/calibration-derived; P-side variation reported.
7. **Do missingness figures disagree?** Resolved — 2.83% all-rows vs 4.19%
   cohort-conditioned; manuscript uses 4.2% with denominator stated.
8. **Is the indicator pair independent?** No claim of independence — presented
   as one diagnostic scale by construction.
9. **Is the case study a JOI fit?** Methodology-first architecture
   (measurement pipeline + audit-in-results) satisfies the case-study clause.
10. **Any residual critical issue?** None found. Format compliance verified
    (≤10k words, TNR 12pt, OMML, landscape Table 10).

**Verdict: no critical issues outstanding.** Author-side placeholders
(author names, affiliations, ORCID, COI) are administrative, not scientific
holds.

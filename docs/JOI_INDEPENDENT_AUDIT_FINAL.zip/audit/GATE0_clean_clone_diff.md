# GATE 0 — clean-clone diff vs submission snapshot

Date: 2026-11-03 (JST)
Verdict: **PASS** (with notes N1–N3)

## Method
- Fresh clone: `git clone https://github.com/bougtoir/researcher-mobility-ode` (single squashed sync commit `82a61fc`, "sync: devin/researcher-mobility-ode-full-article").
- Submission snapshot: `manuscript_full_article_submission.zip` (attached, built 2026-10-03, last zip handed to user).
- Compared `unzip(zip)` vs `unzip(docs/manuscript_full_article_submission.zip)` in the clone, and clone tree vs `wip/researcher_mobility_ode` @ master.

## Findings
- **N1 — Public main is NEWER than the submitted zip.** The only content difference is the "Data and Code Availability" section in `manuscript_full_article.md` / `_blinded.md` (and the docx/pptx binaries regenerated from it). The public repo + manuscript now say author-level derivatives are not redistributed and `reproduce.sh` re-extracts from the OpenAlex API; the submitted zip still says "bundled with a pre-extracted cohort and a stratified sample of works". → **The next submission must rebuild the zip from current main**, otherwise the availability text will contradict the repository it cites.
- **N2 — All figures (PNG+TIF, Figure_01–10, Supplementary_Figure_S1–S3) byte-identical** between the submitted zip and the zip in the clone.
- **N3 — Author-level derivatives correctly absent from public repo**: `data/cohort/cohort.csv`, `raw_sampled_works.json`, `data/cohort/pi_proxy/cohort.csv`, `data/cohort/pi_proxy/raw_sampled_works.json`, `data/cache/` exist only locally (wip private checkout / regenerable). `data/cohort/transition_rates.csv`, `pi_proxy/transition_rates.csv`, `author_origin_overrides.csv`, mapping JSON, geojson are published as designed.
- **N4 — audit file note confirmed**: zip contains no analysis code or raw data (manuscript + supplement + figures + cover letter only), by design — code lives in the repo.

## Clean-clone reproduction (in progress)
`bash reproduce.sh` in the fresh clone: full-population re-extraction triggered automatically (pi_proxy cohort absent). OpenAlex API key from session secrets. Log: `logs/reproduce_clean_clone.log`. Rate ~15-20 pages/s; ~3.4M works expected; classification + full pipeline follows. Result comparison vs `results/` committed values will be appended below when finished.

## Snapshot-difference caveat
OpenAlex updates continuously; fresh extraction is expected to reproduce rates/rankings "up to small snapshot differences" (manuscript §5.5 already reports a snapshot check: 719,173 vs 723,647 authors).

## Addendum — full-pipeline re-run (this session)

- **On committed data** (`data/cohort` n=723,647; `data/cohort/pi_proxy` n=719,173):
  `bash reproduce.sh` completed end-to-end; all deterministic CSVs regenerate
  identically to ~15 significant digits (float last-digit noise only);
  `bootstrap_ci/bootstrap_draws.csv` differs as expected (stochastic). PASS.
- **Clean-clone reproduction**: the REEXTRACT path of `reproduce.sh`
  (`src/cohort_extraction.py` stratified sample, 112 batches) yields n≈2,340
  authors and cannot reproduce the committed population rates (p_abroad
  inflated 30–120%) — the script must be pointed at the full-population
  extractor for reviewers. FLAG for public-repo fix.
- **Fresh complete re-extraction** (OpenAlex, all 24 partitions DONE):
  3,336,343 works → 623,176 cohort authors vs 719,173 committed (−13.4%,
  upstream OpenAlex churn). Fresh p_abroad systematically ~25–30% lower
  (Sinic 0.097 vs 0.127; US 0.148 vs 0.203; Japanese 0.094 vs 0.138;
  CE 0.117 vs 0.155). Per the audit's rule, if resubmission uses a fresh
  snapshot, abstract and policy conclusions must be regenerated from it.
- Silent-truncation finding filed in FINDING_silent_truncation.md.

# JOI Final Handoff v2

## Deliverables (in `docs/`, branch `devin/20261104-joi-gate5`, public repo)

- JOI_MANUSCRIPT_FINAL_v2.docx / JOI_MANUSCRIPT_BLINDED_v2.docx
- JOI_MANUSCRIPT_FINAL_v2.md (markdown mirror)
- JOI_COVER_LETTER_v2.docx, JOI_TITLE_PAGE_v2.docx, JOI_HIGHLIGHTS_v2.docx
- JOI_FIGURES_EDITABLE_v2.pptx
- JOI_SUBMISSION_PACKAGE_v2.zip
- supplementary_material.docx
- audit files in wip `researcher_mobility_ode/audit/` (this directory);
  JOI_INDEPENDENT_AUDIT_EVIDENCE_v2.zip bundles them.

## What changed vs v1

Scientific: §3.7 origin-ranking fix (fixed-M analysis; conflation disclosed);
collapse-rule independence sentence in §3.9; monitoring-diagnostic downgrade
complete; critical-factor phrasing disambiguated; Table 2 "r" → "r (fitted)".
Formatting: TNR 12pt black throughout; Table 10 on landscape page; abstract
≤250 words; highlights ≤85 chars.

## Canonical cohort

n = 623,176 (fresh OpenAlex snapshot). All numbers regenerated from code; no
hardcoded values.

## Decision basis

Hostile review v2: zero critical issues. Remaining placeholders are
administrative (author identity/COI). Submission, PR merge, payment and
publisher contact are out of scope by instruction.

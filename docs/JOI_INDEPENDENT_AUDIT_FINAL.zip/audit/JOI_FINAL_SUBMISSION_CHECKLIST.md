# JOI Final Submission Checklist (§13)

## Submission files (docs/)
- [x] JOI_MANUSCRIPT_FINAL_LOCK.docx
- [x] JOI_MANUSCRIPT_BLINDED_FINAL_LOCK.docx
- [x] JOI_COVER_LETTER_FINAL_LOCK.docx
- [x] JOI_TITLE_PAGE_FINAL_LOCK.docx
- [x] JOI_HIGHLIGHTS_FINAL_LOCK.docx
- [x] JOI_FIGURES_EDITABLE_FINAL_LOCK.pptx

## Audit files (wip audit/)
- [x] JOI_REGION_SPECIFIC_M_SENSITIVITY.md / .csv
- [x] JOI_FINAL_NUMERIC_RECONCILIATION.md
- [x] JOI_FINAL_SEMANTIC_CODE_AUDIT.md
- [x] JOI_FINAL_HOSTILE_REVIEW.md
- [x] JOI_FINAL_REFERENCE_AUDIT.md
- [x] JOI_FINAL_FIGURE_TABLE_AUDIT.md
- [x] JOI_FINAL_EQUATION_RENDER_AUDIT.md
- [x] JOI_FINAL_JOURNAL_FIT_AUDIT.md
- [x] JOI_FINAL_SUBMISSION_CHECKLIST.md
- [x] JOI_FINAL_HANDOFF.md

## Packages (docs/)
- [x] JOI_SUBMISSION_FINAL_LOCK.zip (36 files, testzip clean, extracted & verified)
- [x] JOI_INDEPENDENT_AUDIT_FINAL.zip (audit MDs + sensitivity CSVs + canonical result CSVs)

## Claim audit (§6) — full-text check on FINAL_LOCK.md
- "early warning": absent as a capability claim (only monitoring-diagnostic).
- "validated"/"prediction": only in negations and future-work framing.
- "collapse": confined to scenario-assumption definition + verified-inactive
  rule statement.
- "independent indicators/tests": only in negations.
- "robust": only with the algebraic-vs-evidential distinction for M.
- "generalise": only as machinery-design claim, not findings.
- Policy effects: model-conditional lever table, no causal claim.
PASS.

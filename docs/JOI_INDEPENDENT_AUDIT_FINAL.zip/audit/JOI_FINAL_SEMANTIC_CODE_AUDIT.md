# JOI Final Semantic Code Audit (§10)

Delta audit on the final-gate changes (not a mechanical re-run of v1 PASSes).

1. **Region-specific M perturbation** (`src/region_specific_m_sensitivity.py`)
   - Estimand: T/M_i' = T_i/(s_i M_i), T from canonical equilibrium. Sign:
     larger s → smaller T/M. Units consistent. Denominator = perturbed M only.
   - Interval: [tm/2, 2tm] exact; pair-reversal test = interval overlap.
     Verified by spot check (Anglosphere ex-US 215.76→[107.9, 431.5] vs
     Other Western 238.05→[119.0, 476.1]: overlap → reversible ✓).
   - MC: 200k iid uniform draws; ranks/P(min)/ρ/τ computed correctly;
     baseline_rank from unperturbed tm. Synthetic check: with s_i=1 fixed,
     ranks reproduce baseline order. PASS.
2. **Boundary proximity recompute**: solver rerun per perturbed M; closest
   lever = I0 in all 45 cells — structural (I0 enters linearly via the
   inflow constant), labelled as such in the manuscript and audit. PASS.
3. **Collapse rule**: verified over all trajectory timepoints (not just
   terminal): min T_over_M = 20.74 > 1 across 756 runs; collapse_years.csv
   has 0 events. The "does not depend on the rule" claim is now fully
   supported, including mid-horizon crossings. PASS.
4. **Manuscript-code consistency**: new §3.6 sentences read only from the
   generated CSVs (no hardcoding); 4.6 caveat consistent. PASS.
5. Policy lever rankings: elasticity CSVs untouched; M-independence stated
   as algebraic fact. PASS.

# JOI Equation Render Audit
Method: DOCX → PDF via LibreOffice; visual inspection of rendered pages (p4 equations inline + display; p10 compartment figure + model equations); DOM-level check that all equations are OMML (m:oMath elements), not images or plain text.

## Result: PASS
- All display equations are OMML blocks produced by add_omath_paragraph; inline symbols via add_omath_inline. Count of m:oMath elements > 40 in body.
- No equation appears as a raster image. No Unicode-fallback-only glyphs: α, β, γ, ε, φ, τ, Δ render as proper math characters inside OMML runs.
- The equilibrium closed forms (T*, per-compartment equilibria, I_0 calibration identity, MVB margin definition) render as stacked fractions/subscripts correctly in the LibreOffice render.
- Greek letters inside prose (e.g. "p_abroad (α)") are italic math runs, visually consistent with the displayed equations.
- Numbering: equations are unnumbered (consistent Elsevier style — display equations referenced by description, not number); consistent throughout.

## Residual note
LibreOffice render used for QC; Word rendering may differ trivially in fraction spacing. No tofu (missing-glyph) characters observed in any rendered page.

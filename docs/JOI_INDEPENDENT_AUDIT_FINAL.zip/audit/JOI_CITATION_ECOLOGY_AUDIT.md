# JOI Citation Ecology Audit
52 distinct references, numbered by first appearance (Vancouver order, mechanically verified by check_manuscript.py: 52 cited = 52 listed, 0 orphans, 0 phantoms).

## Composition
| Category | Count | Examples |
|---|---|---|
| Informetrics/science-of-science core (mobility, collaboration, impact, OpenAlex, mobility measurement) | ~14 | appelt, franzoni, stephan, scellato, hunter, moed, sugimoto, chinchilla, yuan, openalex, alshebli, state, laudel, jonkers |
| AI/ML field + homogenisation concerns | ~10 | bresnahan, macropolo, sevilla, ahmed, kleinberg, hooker, koch, joshi, bender, raji, kaplan, bommasani |
| Method/theory anchors (innovation systems, diversity, path dependence, extinction analogies) | ~17 | arthur, nelson, dosi, lundvall, malerba, metcalfe, saviotti, hongpage, jones, freeman, aghion, stirling, shaffer, saether, soulé, lande, gilpin |
| Historical narrowing cases | ~9 | olazaran, rumelhart, joravsky, colander, smolin, ullstrup, mccook, avelino, ploetz |
| Disruption/field-size evidence | ~3 | chu, park, plus supporting |

## Ecology properties
- Self-citation: none of the author's own prior work is cited; no citation-cartel pattern.
- Venue breadth: references span Econ J, Nature, Science, PNAS, Research Policy, Scientometrics, JRSI, JEL — no single-journal over-concentration; appropriate for JOI's interdisciplinary audience.
- Recency: pre-2000 classics are theory anchors only (Jevons 1865 via alcott; Shaffer 1981; David 1985; Arthur 1989; Katz & Shapiro). Empirical anchors are 2015–2024.
- Geographic/topical bias: mobility literature is heavily US/Europe-centric; acknowledged in Limitations as a literature-level gap, not a citing bias of ours.
- JOI audience fit: ~1/3 of refs are informetrics/quantitative science studies — matches journal scope; theory refs are load-bearing (each supports a stated mechanism or analogy claim).

## Issues found
- arXiv-hosted items (openalex, koch, raji, kaplan, bommasani, ahmed) carry arXiv DOIs (10.48550/*) that resolve via DataCite, not Crossref — verified live 200 responses. Acceptable for format-free submission.
- 4 references carry no DOI (stephan JEL 1996, shachar, david, katz): real publications; DOI omission is acceptable under format-free submission. Flagged only.

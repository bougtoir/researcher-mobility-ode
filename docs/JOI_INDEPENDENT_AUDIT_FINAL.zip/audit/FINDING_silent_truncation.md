# FINDING (Gate 0, severity: high) — silent truncation on OpenAlex budget exhaustion

Date: 2026-11-03

## What happened in the clean clone
`bash reproduce.sh` → `src/extract_full_cohort.py` hit `OpenAlexBudgetExhausted`
("Rate limit exceeded: 30 requests per second") at ~2.87M works. The exception
is raised inside the **writer thread** (`_writer`, extract_full_cohort.py:392);
`_fetch_partition` correctly pushes an `ERROR` item and sets `stop_event`, but
the exception dies inside `threading.Thread`. `fetch_and_store` then returns
normally, prints `Fetch complete`, and `main()` proceeds to
`classify_all_authors` on the truncated DB.

## Evidence
- `logs/reproduce_clean_clone.log`: `Exception in thread Thread-1 (_writer) ...
  OpenAlexBudgetExhausted` followed by `Fetch complete: 21753 pages,
  2,868,502 works, 8,544,363 author_works rows` and classification.
- `data/cache/full_cohort_state.json`: partitions 2000-2009 `cursor=DONE`;
  2010-2023 hold mid-stream cursors (~900-1100 pages each, unfinished).
- Result: `data/cohort/pi_proxy/cohort.csv` = 602,502 authors vs 719,173 in the
  published snapshot — a ~16% undercount driven by truncation + snapshot drift,
  indistinguishable from a "legitimate" fresh extraction in downstream output.

## Why it matters
The README promises fresh extraction "reproduces the published rates up to
small snapshot differences". With this bug a third party on a budget-limited
API plan silently reproduces a *different* cohort and different rates — the
exact failure mode the audit's "fail-loud" requirement exists to prevent.

## Fix (recommend for revision PR)
1. In `fetch_and_store`, after `writer.join()`, verify every partition's
   cursor == "DONE"; if not, `sys.exit(1)` with a resume hint — OR re-raise
   the writer's exception in the caller (capture it from `_writer` and
   re-raise after join).
2. Optionally add a summary line `partitions complete: n/24` to the log and to
   the cohort README written at extraction time (records snapshot date +
   completeness — strengthens provenance, cheap).
3. Resume command that works today: `python src/extract_full_cohort.py
   --output-dir data/cohort/pi_proxy --workers 10` (state file resumes each
   unfinished partition at its saved cursor; --workers 10 keeps the request
   rate under the 30 rps limit — this run completed the remaining partitions).

## Second issue observed
`reproduce.sh`'s `REEXTRACT`/missing-cohort path runs `src/cohort_extraction.py`,
which builds a **stratified ~5.6k-author sample** cohort (112 batches × 50
authors), not the 723k-author full population the published
`transition_rates.csv` is computed on. A fresh-clone `reproduce.sh` therefore
yields noisy rates that cannot match committed values closely; README's
"reproduces the published rates" overstates this path. Recommend either making
the full-population extraction the default cohort path, or stating the sampled
cohort's expected deviation explicitly.

## Quantified consequence (sampled vs full-population cohort)
The clean-clone reproduce produced `data/cohort/cohort.csv` with **n = 2,340
authors** via the stratified-sampling path; the published cohort is n = 723,647.
Comparing the resulting `data/cohort/transition_rates.csv` with the committed
full-population values:

| group | n (sample/full) | p_abroad sample | p_abroad full | inflation |
|---|---|---|---|---|
| United States | 396 / 134,807 | 0.326 | 0.203 | +60% |
| Sinic | 436 / 190,051 | 0.275 | 0.126 | +118% |
| Continental Europe | 419 / 168,911 | 0.339 | 0.154 | +120% |
| Japanese | 205 / 32,007 | 0.180 | 0.138 | +31% |
| Other Western | 167 / 4,397 | 0.413 | 0.322 | +28% |

Stratified sampling of works systematically over-weights mobile and prolific
authors: `p_abroad` is inflated ~30-120% in every macro-region, so downstream
alpha, beta and the equilibrium cannot be called reproductions of the
published values. The clean-clone reproduce therefore does NOT reproduce the
manuscript's rates — it reproduces a qualitatively similar but numerically
different analysis. Verdict on the audit ask "clean-clone reproduction of
public main": **FAIL for the main cohort path**; the only faithful path is the
full-population extraction (`extract_full_cohort.py`, used for pi_proxy),
which itself needed `--workers 10` after the rate-limit truncation above.

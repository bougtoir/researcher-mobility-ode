# JOI Incremental-Information Audit (v2, P7)

## The hostile question

"Is the proposed indicator genuinely informative, or is it largely a
deterministic transformation of the fitted equilibrium and an arbitrarily
defined threshold?"

## Honest answer adopted in the manuscript

- T/M and boundary proximity ARE linked by construction: proximity is the
  closest-lever reading of the same margin scale. The abstract now says so
  verbatim ("they form one diagnostic scale, not two independent tests") and
  the "indicator pair" phrasing is qualified everywhere it appears.
- What the pair adds over the raw rate table: it normalises each region's
  equilibrium by its own empirically observed coauthor scale M, producing a
  single recomputable margin scale that ranks regions differently from raw
  size (Anglosphere ex-US lowest at 215.8 despite a large pool; Japan 293.0).
- What it does NOT add: independent predictive evidence. Backtest results
  (§3.5) are weak and are disclosed as such; validity claims are deferred to
  the future-validation agenda (§4.7).
- The M definition (k median last-author groups × c̄ mean coauthors) is
  arbitrary in the sense of being one operationalisation among several;
  §2.7 and §3.7 disclose this and report the M×0.5–2.0 robustness band
  (rankings and closest lever unchanged).

## Verdict

The paper no longer presents a deterministic transformation as an independent
indicator; the single-scale framing plus the disclosed robustness band is the
defensible position. PASS.

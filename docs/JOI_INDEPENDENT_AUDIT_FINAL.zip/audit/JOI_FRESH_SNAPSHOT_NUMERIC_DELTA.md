# JOI Fresh-Snapshot Numeric Delta Audit (v2, P6)

## Missingness denominator reconciliation

- Gate-1 reported 5.9% country missingness — computed over the earlier
  snapshot's raw fetched authorship rows (pre-dedup denominator, old
  719,173-author extraction).
- Fresh canonical pass (`results/measurement_validity/MISSINGNESS.csv`,
  MISSINGNESS_SUMMARY.csv):
  - all authorship rows in DB: 9,929,165; missing country 280,743 → **2.83%**.
  - cohort-conditioned rows: missing share **4.19%**
    (share_missing_country_cohort).
- Manuscript §3.7/§4.6 reports the 4.2% cohort-conditioned figure with the
  denominator stated. The 5.9% figure is superseded and no longer appears.
  RESOLVED.

## PI-ratio discrepancies

- Older audits quoted PI shares from the 719k extraction; the v2 manuscript
  reports only fresh-snapshot shares (10.1–81.6% across the 6 definitions,
  per-region 9.9–87.2%). Old-vs-fresh deltas for all headline rates are in
  JOI_OLD_VS_FRESH_RESULTS.md. RESOLVED.

## Other snapshot deltas rechecked

- n: 623,176 (canonical) everywhere; no stale 719,173 reference in the v2
  build (grep-verified).
- p_abroad fresh values (US 0.148, Sinic 0.097, Japan 0.094) match
  `transition_rates` output. PASS.

# JOI Early-Warning Claim Audit (v2, P3)

## Claim taxonomy applied

- Computable diagnostic: T/M and boundary proximity — claimed.
- Model-based monitoring: repositioned as "monitoring diagnostic" —
  claimed with the no-validated-prediction caveat.
- Validated early warning: NOT claimed anywhere in v2.
- Predictive system: NOT claimed.

## Changes verified in build output

- Abstract: "monitoring indicator pair … one diagnostic scale, not two
  independent tests … we claim no validated predictive power."
- §2.7 end: "a diagnostic monitoring device, not a demographic projection."
- §4.x: predictive value flagged as "a separate, unvalidated question (§4.7)".
- §5 conclusion: "monitoring diagnostic pair".
- Cover letter: same monitoring-pair phrasing, no early-warning language.

## Backtest honesty

§3.5 retains the weak out-of-sample result (skill-ratio direction agreement
21.6%; no improvement over the historical-mean baseline) — this is now the
explicit basis for the downgrade from "early warning" to "diagnostic
monitoring". The warning-signal framing is reported as a limitation, not a
finding. PASS.

# JOI Final Handoff (§15)

- Final decision: **JOI CONDITIONAL SUBMIT** (author-side administrative
  placeholders only; zero scientific holds).
- Target journal: Journal of Informetrics (maintained; RE switch not needed).
- Branch: public `devin/20261104-joi-gate5`; wip `devin/1793781351-aiml-resubmission`.
- Canonical cohort: n = 623,176.
- Scientific changes this gate: region-specific independent M perturbation
  added (all 36 pairs reversible; P(min)=36% for baseline minimum; Japan
  rank 1–9); common-multiplier M invariance relabelled as algebraic;
  §3.6/§4.6/abstract/cover letter updated; collapse-rule independence now
  verified over all trajectory timepoints.
- Numerical changes: none to canonical outputs; new CSVs under
  results/region_specific_m/.
- Region-specific M results: see JOI_REGION_SPECIFIC_M_SENSITIVITY.md.
- Remaining limitations: M not externally validated (now a stated, quantified
  limitation); affiliation ≠ physical mobility; rate stationarity; editorial
  taste risk on methods-paper framing.
- Exact PR to merge: https://github.com/bougtoir/researcher-mobility-ode/pull/1
  (public main is behind because the PR is unmerged — unmerged ≠
  reproducibility failure).
- Human actions: fill author/affiliation/ORCID/COI/funding placeholders →
  merge PR → submit via Editorial Manager.
- Not done (by instruction): submission, PR merge, payments, publisher contact.

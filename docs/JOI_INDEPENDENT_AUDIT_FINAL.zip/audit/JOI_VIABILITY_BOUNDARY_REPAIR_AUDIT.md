# JOI Viability-Boundary Claim Audit (v2, P2)

## Terminology map (verified sentence-by-sentence in the v2 build)

- §2.9 defines dynamics / boundary / approach / crossing / collapse /
  irreversibility separately; "point of no return" renamed to
  "model-implied viability boundary" throughout.
- §2.10 collapse rule (r→0 once T<M) is labelled an external scenario
  assumption, not a data-derived property.
- Intro now reads: a state variable "that tracks, in model terms, whether a
  system retains the capacity to reproduce its workforce" — no validated
  early-warning claim.
- Every M mention describes it as an operational benchmark / model-implied
  boundary; external validation is framed as future work (§4.7).

## M construction verification

`src/ode_model_endogenous.py`: M = k_groups × c_bar where
- k_groups = median number of distinct last-author groups per recent year
  (per macro-region);
- c_bar = mean authors per work.
Units: groups × authors/work = authors. Anglosphere ex-US: 84 × 3.17 = 266.3 ✓.
The manuscript §2.7/§3.2 describes this construction accurately (median
independent last-author groups × mean coauthors), states the window, and
discloses it as an operational benchmark without external demographic
validation.

## Collapse-rule-off comparison (new in v2)

`results/dominant_strategy/collapse_years.csv`: 0 collapse events across all
756 scenario runs; minimum terminal T/M ≈ 20.7 (φ=8, γ=2) — no region
approaches M within the horizon. §3.9 now states: "the collapse rule never
activates in any run, so these outcomes do not depend on that scenario
assumption." This replaces the previously unverifiable claim.

## Residual caveats kept

- "evolutionary dead end" in §3.9/§4.5 is inside the scenario framing and
  hedged by the collapse-rule disclaimer.
- Figure 10 caption's "crosses mark when a region falls below M" retained —
  no crosses appear because no region crosses; caption is descriptive of the
  marker semantics, not a data claim.

# JOI Final Figure/Table Audit (§8)

- check_manuscript.py on JOI_MANUSCRIPT_FINAL_LOCK.docx: Figures 1–10 and
  Tables 1–10 all cited in text and captioned; first-mention order matches;
  all mechanical checks passed.
- Table 10 on dedicated landscape section (portrait→landscape→portrait).
- PDF render audit: LibreOffice conversion OK; 45 pages; zero U+FFFD
  replacement glyphs; Greek letters (α β γ ε ρ τ φ) and × ± ≈ ∈ present.
- Styles: Normal + Heading + Caption = Times New Roman 12pt black; figure/
  table caption style 12pt black (spec asks ≥10pt — compliant); no
  artificial letter-spacing; no markdown asterisks in docx.
- Figure numbering: Figure_01–Figure_10 + Supplementary S1–S3, PNG+TIFF,
  filenames use mvb (not pnr). PASS.

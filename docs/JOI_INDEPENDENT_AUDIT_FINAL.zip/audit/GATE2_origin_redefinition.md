# Gate 2 — Origin redefinition sensitivity

**Verdict: PASS** (qualitative conclusions unchanged under alternative origin rules;
three wording/limitation items flagged for the resubmission).

## What was run

`src/origin_robustness.py` (new; mirrored into the public repo clone) streams all
9,929,165 authorship rows from the fresh complete extraction
(`data/cache/full_cohort.db`, all 24 partitions DONE, 3.34M works) and re-derives
origin/abroad for the 623,176-author fresh pi_proxy cohort under three rules:

| rule | definition |
|---|---|
| `window3_mode` (baseline) | modal macro-region over works in the first 3 career years, earliest-appearance tiebreak — the shipped implementation |
| `first_year` | modal macro-region over works in the career-start year only (R2's "first observed affiliation") |
| `career_mode` | modal macro-region over the whole career |

`abroad` re-derived under each rule with the same 6-year window; `hit`, `pi`,
`active`, `recent_group` carried from the cohort (origin-independent). Rates
(`estimate_rates`) and the endogenous ODE + PNR scan re-run per rule.

Evidence: `results/origin_robustness/{origin_rule_agreement,origin_rule_rates,
origin_rule_equilibrium,origin_rule_flows,origin_rule_rank_agreement}.csv`
(public clone); log `logs/origin_robustness.log`.

## Findings

1. **Assignment agreement is high.** Same-origin share vs baseline:
   window3_mode 99.8% (sanity check), first_year 98.9%, career_mode 94.5%.
   share_abroad: 0.127 → 0.127 (first_year) → 0.142 (career_mode).
2. **8.4% of authors have ≥2 distinct affiliation groups in a year** — the
   multi-affiliation identifiability limitation is real and quantified.
3. **Rank-level conclusions are stable.** T/M argmin group identical under all
   three rules; closest-PNR group identical; Spearman ρ vs baseline: T/M 1.0/1.0/1.0,
   α 1.0/0.98/0.83, p_abroad 1.0/0.98/0.83. career_mode mechanically imports
   post-mobility affiliations into "origin" (circularity) — reported as a bound,
   not a plausible alternative.
4. Multi-affiliation years are handled by taking the set of groups per
   (author, year) and counting each group once in the mode tally — disclosed in
   the script docstring; a same-year two-group tie counts both.

## Required follow-ups for resubmission

- Manuscript §3.2 currently says origin = "modal country of recorded
  affiliations"; the implementation is modal *macro-region over the first 3
  career years*. Align text to code.
- Rename/qualify "origin": it is an *early-career affiliation mode*, not
  nationality or physical residence. Add first_year rule as a robustness row and
  state the multi-affiliation/physical-move non-identifiability explicitly
  (8.4% multi-affiliated authors; direction of physical moves unobservable).
- Physical mobility vs affiliation mobility: abroad events are affiliation
  changes — already the paper's estimand, but say so in the limitation.

## Residual risk

LOW-MEDIUM. Origin choice does not move rankings or PNR targets; only the level
of share_abroad shifts by ≤1.5pp. Fresh-snapshot drift (see FINDING) is a much
larger effect than origin-rule choice.

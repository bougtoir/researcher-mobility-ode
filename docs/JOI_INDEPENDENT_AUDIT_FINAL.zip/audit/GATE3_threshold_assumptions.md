# GATE 3 — threshold / claim assumption-dependence

Date: 2026-11-03 (JST)
Verdict: **PASS** — every element the audit lists already exists and is reported with the required caveats; residual wording-only item (R1).

## Audit asks → existing evidence

1. **"T/M = 3.01–97.12 and Other Western 67% inflow drop must not be treated as observed real-world collapse points."**
   - Source verified: Other Western `critical_factor` for the I0 lever = 0.340 → a 66% (reported ~67%) drop in fitted exogenous entry reaches M. These are fitted-model quantities on the Aug-2026 snapshot.
   - Manuscript already frames them as model-conditioned: "irreversibility is a property of the collapse rule, not an empirical finding", "PNR denotes the threshold at which the fitted feedback loop stops sustaining the pool, not a prediction" (§6.6); scenario outputs are "model-consistent projections that rank strategies, not predictions" (§6.6, talent-concentration).
2. **"閾値無しの比較モデル" (comparison without the threshold).**
   - Exists: `results/robustness_linear_vs_saturating_pnr.csv` + Supplementary Table S7 (linear vs saturating inflow PNR). The M-free reading is implicit: T, elasticity and lever rankings are reported independently of crossing M (Tables 4-7 use T/M *and* proximity; sensitivity S6 bootstrap CIs are on T itself).
   - R1 (wording): the manuscript does not yet carry a single sentence stating that the *rankings* survive removal of the collapse rule. Cheap fix: one sentence in §5.5 citing m_sensitivity + S7. Recommend adding during revision; not blocking.
3. **"代替最小グループ数" (alternative minimum group counts).**
   - Exists: `src/m_sensitivity.py` → `results/m_sensitivity/`, M × 0.50–2.00: no region falls below M even at 2×M (min T/M 1.51); T/M and proximity rankings invariant (ρ=1.00); |elasticity to d| > |elasticity to α| at every multiplier in all 9 regions; closest lever flips only for Other Western at M≥1.25× (I0→d). Supplementary Table S11.
4. **"モデル予測検証" (model prediction check).**
   - Exists and honestly negative: Supplementary S2/S3 backtest — 2017–2023 projection vs observed reconstruction: rate RMSE 0.0892, skill ratio 0.99 vs historical-mean baseline (i.e. **no improvement over the mean**), direction agreement 21.6%; the 5 observed below-M years are disclosed as cohort-closure artefacts. This is already reported — a strong audit answer, keep.

## Summary for revision
Threshold dependence is fully disclosed and stress-tested along every axis the audit names except one one-sentence framing note (R1). Numeric values are model-conditioned and the text says so.

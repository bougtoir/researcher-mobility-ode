# JOI Old vs Fresh Results Comparison
Old cohort (submission snapshot): n = 719,173 authors (OpenAlex 2024-era extraction).
Fresh canonical cohort: n = 623,176 authors (re-extraction, full pipeline). Change: −13.4%, due to OpenAlex author disambiguation churn between extraction versions.

## Key rate changes (old → fresh)
| Group | p_abroad old | p_abroad fresh | Δ |
|---|---|---|---|
| Sinic | 0.127 | 0.097 | −24% |
| United States | 0.203 | 0.148 | −27% |
| Japanese | 0.138 | 0.094 | −32% |
| Other Western | — | 0.274 | (see fresh table) |
Fresh p_abroad means range 0.094–0.274 across 9 macro-regions.

## What changed
- All transition rates recomputed on 9,929,165 authorship rows / 3,336,343 works (stratified sample 20,400 works for raw checks, seed 42).
- PI shares (fresh): pi_last 55–71%, pi_corr 35–54%, pi_last2 46–52% per group; career8 56.7%, centrality 10.1%, combined 81.6% (cohort-level).
- Missingness audit: country missing 4.19% of cohort authorship rows; left-censor 5.74%; median span 9y.

## What did not change (structural)
- Ranking of macro-regions by T/M proximity to MVB: unchanged ordering, minimum = Other Western.
- Closest policy lever: I_0 (entry) for the systems nearest the boundary — unchanged.
- Zero mobility-direction reversals across all 7 origin specifications — unchanged.
- Qualitative conclusions (early-warning indicator design, leakage asymmetry, endogenous recruitment) — unchanged.

## Manuscript policy
All numbers in the JOI manuscript are read from fresh pipeline outputs at build time (no hardcoded values); the old numbers exist only in this audit and the archived submission snapshot.

# GATE 1 — PI alternate-definition trace

Date: 2026-11-03 (JST)
Verdict: **PASS** — the trace demanded by the audit already exists end-to-end and is internally consistent; one artifact flagged (A2).

## What exists
- Extraction: `src/extract_full_cohort.py` (schema v2, `authorships.is_corresponding` retained) → `data/cohort/pi_proxy/cohort.csv` with `pi_year_{first_last,corresponding,recurrent_last}` for all 719,173 authors on one snapshot.
- Analysis: `src/pi_proxy_robustness.py` → `results/pi_proxy/{pi_proxy_snapshot,pi_proxy_rates,pi_proxy_equilibrium,pi_proxy_rank_agreement}.csv`.
- Manuscript: §5.5 paragraphs + Supplementary S3 / Tables S9–S10; baseline-vs-published Spearman = 1.00 for T, T/M, proximity (same definition, different snapshot).

## Verified claims (recomputed from results CSVs, not retyped)
- PI share by definition: 0.681 / 0.505 / 0.451 overall; regional means reported as 67.4/51.3/48.2% — consistent.
- **Invariant-by-construction (NOT evidence):** T, T/M, entry-lever (I0) proximity — I0 calibrated to match observed entry, so these cannot move. Manuscript already states this explicitly ("invariant to the proxy by construction ... reported only for completeness"), satisfying the audit's warning against reading it as robustness.
- **Proxy-dependent quantities DO vary as expected:** p_D e.g. Japan 0.064→0.048–0.052, P_D, I0/r split, elasticity of T to p_D (0.21–0.36 → 0.30–0.51 under stricter proxies).
- **Policy ranking check (audit §2 ask):** closest lever for T is I0 in all 9 regions under all 3 definitions; closest lever for P_D changes only in Other Western (Israel) → d under both stricter proxies. Spearman on proxy-dependent rankings: p_D ρ=0.73/0.87, P_D ρ=0.98, proximity_P ρ=1.00, elasticity ρ≥0.73. Conclusion: policy ordering is robust in 8/9 regions; Israel is small-n (4,227 authors) and already caveated in the manuscript.

## Flagged artifact
- A2: `spearman_pi_inflow_share = −0.13` for `corresponding` in `pi_proxy_rank_agreement.csv` is a degenerate statistic: `pi_driven_inflow_share` is 0.5 in every cell (safety-factor cap saturates), so rho over near-tied values is noise. Recommend dropping that column from the rank-agreement table or annotating it "capped — not informative" in the supplement.

## Residual gap vs reviewer ask
- Reviewer asked to "not assert what a PI really is": manuscript already scopes PI as "any author with an independent last-author paper, not a tenured group leader" (§3.2). PASS.

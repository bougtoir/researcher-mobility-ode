# JOI Journal Fit Audit (Gate 4 re-audit)
Official source verified 2026-11-04: https://www.sciencedirect.com/journal/journal-of-informetrics/publish/guide-for-authors

## Explicit JOI suitability test (answered)
1. **Scope fit.** JOI: "quantitative aspects of information science ... bibliometrics, scientometrics ... and research evaluation," encouraging "methods from other quantitative fields." Our contribution = a measurement pipeline (researcher identification, geographic attribution, mobility transitions, PI operationalisation, community aggregation) + a calibrated dynamical model producing early-warning indicators for research systems — squarely research evaluation / science-of-science. PASS.
2. **Case-study clause.** JOI excludes case studies "unless they contain innovative methodological elements." Mitigation implemented: the manuscript's contribution statement, abstract, cover letter and §4.3 all center the methodological contribution; AI/ML is explicitly framed as the calibration/illustration case, and the field-agnostic transfer claim is stated. This is the strongest possible in-text response; residual desk-reject risk acknowledged in §7 of journal_decision.md.
3. **Method emphasis.** 10-subsection Methods with a dedicated measurement-validity Results section (§3.7, Table 8) — beyond typical JOI empirical papers. PASS.
4. **Length/format.** ~9.1k words ≤ 10k; single-anonymized; Vancouver acceptable at submission. PASS.
5. **Review ecosystem.** JOI referees evaluate measurement claims in bibliometrics routinely; our strongest claims are measurement-validity claims — appropriate venue. PASS.
6. **Policy relevance.** Lever rankings are model-conditional and relegated to Results §3.9 + Table 10 with conditions/uncertainty columns — consistent with JOI's empirical rather than policy-prescriptive norm. PASS.
7. **Charges.** Hybrid; subscription route = zero mandatory charge → satisfies the standing Q1 + zero-mandatory-charge filter. PASS.

## Research Evaluation fallback (if JOI rejects)
OUP, IF 2.7 Q2, 8–10k words, abstract ≤250, double-anonymized → would require dropping author info entirely and shortening Discussion; materials already mostly compatible.

## Verdict
JOI suitable, with the case-study clause addressed by the methodological framing. The JOI-first order stands per user instruction; RE fallback documented.

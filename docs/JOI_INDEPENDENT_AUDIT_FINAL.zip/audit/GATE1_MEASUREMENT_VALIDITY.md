# GATE1_MEASUREMENT_VALIDITY — origin / mobility / multi-affiliation / PI / missingness

Verdict: **PASS** for origin & multi-affiliation axes (rankings and closest
lever invariant under all tested rules); PI-propagation section complete when
PI_SENSITIVITY.csv lands. Fresh snapshot n=623,176.

Evidence: public clone `results/measurement_validity/` —
ORIGIN_SENSITIVITY.csv, MOBILITY_SENSITIVITY.csv, MOBILITY_MULTISTATE.csv,
MISSINGNESS.csv, MISSINGNESS_SUMMARY.csv, PI_SENSITIVITY.csv,
COAUTHOR_COUNTS.csv. Code: `src/measurement_validity.py`, log
`logs/measurement_validity.log`.

## 1.1 Origin definitions (A–D + window variants)

Rules evaluated: window3_mode (baseline A), first_year (B, earliest observed),
window2 / window5 (C early-career k), probabilistic (D, seeded draw
proportional to first-3y counts), plus multi-affiliation specs fractional and
exclusion.

| rule | n | share retained vs baseline | min T/M group | closest PNR lever | direction reversals |
|---|---|---|---|---|---|
| window3_mode | 623,176 | 99.8% same-origin | Other Western (T/M≈89) | I0 (factor≈0.011) | — |
| first_year | 609,321 | 98.9% | Other Western (≈89) | I0 | 0 / 54 cells |
| window2 | 617,844 | — | Other Western (≈89) | I0 | 0 |
| window5 | 623,176 | — | Other Western (≈89) | I0 | 0 |
| fractional | 623,176 | — | Other Western (≈89) | I0 | 0 |
| exclusion | 619,563 | — | Other Western (≈88) | I0 | 0 |
| probabilistic | 623,176 | — | Other Western (≈87) | I0 | 0 |

- share_abroad range across rules: 0.127–0.142 (aggregate); per-group
  p_abroad shifts ≤ ~3pp (US largest mover under probabilistic, 0.231→0.253).
- **Zero mobility-direction reversals** across all rule×group cells.
- T_over_M ranking essentially unchanged (min always Other Western; max always
  Sinic); equilibrium levels move <3%.

## 1.3 Multiple affiliations

- 8.4% of cohort authors have ≥2 distinct affiliation groups in ≥1 year;
  multi-state membership counts (MOBILITY_MULTISTATE.csv) exceed cohort n by
  ~5% in large groups (e.g. US 117,440 vs 104,397).
- fractional (weight 1/k) and exclusion (drop multi-group author-years) specs
  change cohort n by ≤0.6% and all outputs by ≲2%: multi-affiliation handling
  is not decision-relevant, but must be disclosed.

## 1.4–1.5 PI identification & propagation

Six definitions implemented and each propagated through
estimate_rates → endogenous ODE → PNR scan (PI_SENSITIVITY.csv,
PI_PROPAGATION_P.csv):

| def | mean PI share (fresh) | (committed, n=719k) |
|---|---|---|
| pi_last (ever last author) | 65.3% | 67.4% |
| pi_corr (ever corresponding) | 46.7% | 51.3% |
| pi_last2 (last author ≥2×) | 45.0% | 48.2% |
| pi_career8 (span ≥8y) | 56.7% | new |
| pi_centrality (coauthors ≥ group P90) | 10.1% | new |
| pi_combined (last∨corr∨career8) | 81.6% | new |

- T-side (T_eq, T/M): identical to 6+ digits across all definitions —
  invariant *by construction* (I0 calibrated to observed entry). Reported as
  such, not as robustness.
- P-side (P_D_eq, P/M_P, P-target PNR): varies materially (e.g. US P_D_eq
  14.2k–61.3k across defs), **but rankings are stable**: Sinic max and
  Other Western min under every definition; closest P lever is β (return)
  or I0 for every group (α for Sinic) — ordering preserved.
- Wording rule for resubmission: "senior-author proxy", not "PI"; the
  proxies are bounded evidence, never the true PI population.


## 1.6 Missingness & identification

- 583,071 / 9,929,165 authorship rows (5.9%) lack any country code; within
  cohort-author rows 4.2% missing — NOT random: concentrated in specific
  source/year slices (see MISSINGNESS.csv by year).
- 5.7% of cohort careers are left-censored at the 2000 window edge.
- Median observed span 9 y; 27.8% <5 y, 23.8% ≥15 y → observation-length
  heterogeneity biases seniority/PI-type measures upward for long-observed
  authors (state as limitation).
- Corresponding-author flags are OpenAlex-derived and incomplete outside
  recent years — pi_corr is a *lower bound* proxy (state explicitly).

## Required text changes carried to Gate 5

1. Rename "origin" → "observed career origin" / "earliest observed
   affiliation region"; distinguish from nationality/birth country.
2. §3.2 origin sentence must match implementation (modal macro-region of
   first 3 career years).
3. Add multi-affiliation spec sentence + 8.4% figure; affiliation change ≠
   physical relocation.
4. "PI" → "senior-author proxy (last-author)" throughout; keep 3 existing
   definitions + add career-length/centrality/combined rows.
5. Missingness paragraph: 5.9% rows missing country; 5.7% left-censored;
   coverage non-random.

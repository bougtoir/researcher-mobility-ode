# JOI Final Hostile Review (§11)

| # | Question | Assessment | Severity | Residual risk |
|---|---|---|---|---|
| 1 | Is M too arbitrary? | Disclosed as operational benchmark, not a validated collapse threshold; region-specific sensitivity now quantified in main text. | Moderate | M's external validity remains untested — stated plainly. |
| 2 | How much does ranking move under independent M perturbation? | Fully: all 36 pairs reversible; P(min)=36% for baseline minimum; disclosed in §3.6 + §4.6, not concealed. | Addressed | A referee may still see the ranking as fragile — but the paper now says exactly that. |
| 3 | Does T/M add real information? | Normalises fitted equilibrium by observed coauthor scale; disclosed as one diagnostic scale, not an independent indicator. | Low–moderate | Value is the pipeline + audit, not the scalar alone — positioned accordingly. |
| 4 | Is boundary proximity just a transform of T/M? | Closest-lever reading of the same margin; paper says "one diagnostic scale". | Low | — |
| 5 | Is dropout-dominance self-evident? | Elasticity ranking is a model output; reported with the calibration caveat (I0 anchored to observed entry). | Moderate | Structural, not empirical — stated. |
| 6 | Does origin measurement error change rankings? | 7 specs, direction reversals 0/54 aggregate; fixed-M T/M minimum = Anglosphere ex-US under all rules. | Low | Aggregate-level claim only — stated. |
| 7 | How far do PI definitions limit conclusions? | T-side invariant by calibration (declared structural); P-side varies and is reported; PI share absolute values not used for claims. | Low | — |
| 8 | Is weak backtest compatible with "diagnostic framework"? | Yes — the downgrade is built on the disclosed weak backtest (21.6% direction agreement); no warning-system claim. | Low | — |
| 9 | Is the methodological contribution enough for JOI? | Pipeline + main-text measurement audit (origin×7, PI×6, M interval+MC, missingness) is the contribution; single-anonymised review and case-study clause satisfied via methodology-first framing. | Moderate | Desk-reject risk if editors want a substantive informetric finding, not a methods audit. |
| 10 | Is it just an AI-mobility case study? | Pipeline field-agnostic by design; no claim that findings generalise — machinery claim only. | Low | — |

**Outcome: no critical issue outstanding.** The dominant residual risk is
editorial taste (methods-paper framing vs substantive finding), which is
informed risk, not a scientific hold.

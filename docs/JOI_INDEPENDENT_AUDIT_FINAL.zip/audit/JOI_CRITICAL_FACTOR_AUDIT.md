# JOI Critical-Factor Wording Audit (v2, P1)

Terminology checked across abstract, highlights, results, discussion, captions
and cover letter (built docx + `JOI_MANUSCRIPT_FINAL_v2.md`).

## Definitions used (pre-rounding canonical values)

- critical factor cf: multiplicative factor on the rate; e.g. 0.004635.
- remaining share of baseline: cf × 100 = 0.46%.
- required reduction: (1−cf) × 100 = 99.54% (proximity column).
- proximity stored in `closest_point_of_no_return.csv` = 1 − cf.

## Fixes applied

- Earlier draft said a ~"100% reduction" for cf = 0.0046 — reads as if the rate
  went to zero. Now everywhere phrased as: "I0 reduced to 0.5% of its current
  value — a 99.5% reduction — would drive the active pool to M".
- Abstract sentence: "where exogenous entry rate (I_0) reduced to {cf%}% of its
  current value — a {prox%}% reduction — would drive the active pool to its
  threshold." Computed from unrounded CSV values.
- Highlight 3 (≤85 chars): "Closest boundary: Anglosphere ex-US, I0 at 0.5% of
  baseline" — verified length 83 chars.
- Figure 4 caption: states proximity = 1 − critical factor explicitly.
- §3.4 body: "{rate} multiplied by {cf} — that is, the rate reduced to {cf%}% of
  its current value, a {prox%}% reduction — drives the active pool to M."
- Cover letter carries the same phrasing.

## Residual

No remaining sentence reads a multiplicative factor as a direct percentage
reduction or vice versa. PASS.

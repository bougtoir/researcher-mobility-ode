# GATE 4 — target-journal verification (audit §7)

Date: 2026-11-03 (JST). Sources: publisher pages + JCR 2025 release (June 2026).
User's standing filter: **JCR Q1 AND zero mandatory author charges** (full-OA APC / submission-fee journals out; hybrid subscription route fine). Fee exceptions only on explicit user decision.

## Verified candidates

| Journal | IF (2025) | JCR quartile | OA model | Mandatory fee? | Verdict vs filter |
|---|---|---|---|---|---|
| JASIST (J. Assoc. Inf. Sci. Technol., Wiley) | 5.1 | Q1 (Info Sci) | hybrid, optional APC | No (subscription route) | PASS — scope fit: informetrics, mobility |
| Scientometrics (Springer) | 3.8 | Q1 (Info Sci) | hybrid (Open Choice) | No | PASS — natural venue for cohort/mobility ODE audit |
| Journal of Informetrics (Elsevier) | 3.9 | Q1 (Info Sci) | **full OA, APC USD 2,880** | **Yes** | FAILS fee rule — flag to user, needs explicit opt-in |
| Research Evaluation (OUP) | 2.7 | **Q2** (58/172 Info Sci) | hybrid | No | FAILS Q1 rule — audit's provisional #1 does not meet the standing filter |

## Recommended order (subject to user approval)
1. **JASIST** — Q1, no mandatory fee, highest IF in the field; framing: bibliometric cohort reconstruction + mobility/compartment model (fits its informetrics remit).
2. **Scientometrics** — Q1, no mandatory fee, direct audience for cohort-scale OpenAlex analyses.
3. **Journal of Informetrics** — only if user accepts the USD 2,880 APC.
4. **Research Evaluation** — only if the Q1 rule is relaxed for the strongest scope fit.

## Content gate for 1-2 (Reviewer 2's demand)
Reviewer 2 requires either demonstrating AI/ML-specificity vs other fields or downgrading to case study. At JASIST/Scientometrics the informetrics audience will also expect the origin/PI definitional sensitivity completed (Gates 1-2) — recommend holding final journal decision until GATE2 origin results are in, since a null result (origin rule changes nothing) strengthens the JASIST case, while a large effect may force the case-study downgrade the reviewer offered.

## AUTHOR_ACTIONS_REQUIRED
- Confirm target order above, or override (e.g. keep Journal of Informetrics and pay APC, as previously done for JEBO).

# JOI Origin-Ranking Reconciliation (v2, P4)

## The inconsistency

Table 2 (baseline) gives lowest T/M = Anglosphere ex-US (215.76). The earlier
§3.7 text claimed "lowest T/M = Other Western under every origin rule",
contradicting Table 2.

## Root cause

`ORIGIN_SENSITIVITY.csv` recomputes M under each alternative origin rule, so
its `T_over_M` column mixes origin sensitivity with M-construction
sensitivity. Recomputing with M held at canonical values isolates the origin
effect.

## Recomputed (fixed-M) ranking

| origin_rule | min T/M (fixed M) | group | min T_over_M (raw M) | group |
|---|---|---|---|---|
| window3_mode | 210.9 | Anglosphere ex-US | 89.2 | Other Western |
| window2 | 208.7 | Anglosphere ex-US | 89.0 | Other Western |
| window5 | 214.5 | Anglosphere ex-US | 88.7 | Other Western |
| first_year | 206.1 | Anglosphere ex-US | 89.1 | Other Western |
| fractional | 210.8 | Anglosphere ex-US | 89.2 | Other Western |
| exclusion | 206.0 | Anglosphere ex-US | 87.8 | Other Western |
| probabilistic | 203.9 | Anglosphere ex-US | 87.1 | Other Western |

## Resolution in manuscript

§3.7 now reports: with M held at baseline, lowest-T/M = Anglosphere ex-US
under ALL 7 rules, matching Table 2; and adds a parenthetical that the
recomputed-M variant conflates origin with threshold construction. Table 8
row updated accordingly. Lowest-T/M region and lowest-boundary-proximity
region coincide (Anglosphere ex-US, proximity 0.9954) — no contradiction
remains. RESOLVED.

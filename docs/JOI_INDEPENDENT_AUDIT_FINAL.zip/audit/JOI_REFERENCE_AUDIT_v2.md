# JOI Reference Audit v2 (P9)

Carried forward from JOI_REFERENCE_AUDIT.md (v1): all 52 references verified —
existence, DOI resolution (Crossref + DataCite for arXiv; doi.org HEAD 403s on
several publishers are bot-blocks, not dead DOIs), authors, year, title,
journal, volume, pages.

v2 delta:

- Citation registry re-run on the v2 build: 52 distinct citations,
  first-mention order 1–52 matches the numbered list (Vancouver order of
  appearance). `check_manuscript.py` PASS.
- Citation ecology: JOI-relevant prior work retained — researcher mobility
  (Sugimoto et al.), bibliometric indicators (Waltman), science of science
  (Fortunato et al.), career measurement (Petersen), compute-era AI
  (Sevilla et al.). No padding citations added in v2.
- No invented references; REFERENCE_RESOLUTION_LOG.txt in the evidence zip.
PASS.

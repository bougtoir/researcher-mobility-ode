# JOI Final Handoff v3

- Final decision: **JOI CONDITIONAL SUBMIT** — author-side administrative
  placeholders (names, affiliations, ORCID, COI, funding) only; zero
  scientific holds.
- Target journal: Journal of Informetrics.
- Branch: public `devin/20261104-joi-gate5`; wip `devin/1793781351-aiml-resubmission`.
- PR: https://github.com/bougtoir/researcher-mobility-ode/pull/1 (unmerged —
  public main is older; unmerged ≠ reproducibility failure).
- Canonical cohort: n = 623,176 (frozen).
- Scientific changes (v2→v3, prose only): Intro premise (iii)/(iv) reframed
  (M = operational benchmark; sub-M = classification condition; real
  reproduction-stop/irreversibility explicitly an unanswered empirical
  question); §2.9 five-way distinction repaired; "evolutionary dead end" →
  "model-dependent risk of reduced field-level diversity"; Figure 10 caption
  counterfactual + zero-crossing statement; §4.1 opening softened.
- Numerical changes: none (all canonical outputs frozen; Figure 10 caption
  min-trajectory value now computed at build time, not hardcoded).
- Remaining limitations: M externally unvalidated; ranking conditional on
  M; affiliation ≠ physical mobility; rate stationarity; γ unidentified;
  editorial-taste risk on methods framing.
- Exact PR to merge: PR #1 (link above).
- Human actions: fill author/COI/funding placeholders → merge PR → submit
  via Editorial Manager (subscription route; no paid OA).

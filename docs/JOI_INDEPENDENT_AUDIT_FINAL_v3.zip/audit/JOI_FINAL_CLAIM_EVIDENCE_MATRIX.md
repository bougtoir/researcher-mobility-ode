# JOI Final Claim–Evidence Matrix (v3)

| Claim | Location | Supporting analysis | Supporting output | Structural/Empirical | Limitations | Final wording | PASS/FAIL |
|---|---|---|---|---|---|---|---|
| Origin robustness (no direction reversal) | §3.7, Table 8 | ORIGIN_SENSITIVITY + MOBILITY_SENSITIVITY | 7 specs, 0/54 aggregate reversals | Empirical (aggregate level only) | Not individual-level invariance | "never reverse a macro-region's mobility direction" | PASS |
| PI sensitivity | §3.7 | PI_SENSITIVITY, PI_PROPAGATION_P | 6 defs; shares 10.1–81.6%; T-side rho=1.0 | Structural (T-side, by I0 calibration) / Empirical (P-side) | Absolute PI shares non-robust | T-invariance labelled "structural, not evidential" | PASS |
| T/M as margin scale | Abstract, §3.2, Table 2 | equilibrium_summary | T/M 215.76–2803.8 | Structural normalisation of fitted equilibrium | Ranking conditional on M (below) | "monitoring diagnostic … conditional on the operational M" | PASS |
| Boundary proximity | §3.4, Table 4, Fig 4 | closest_point_of_no_return | cf I0 0.0025–0.0046, proximity 0.995–0.998 | Structural (fitted-model algebra) | Closest-lever reading of same margin | "one diagnostic scale, not two independent tests" | PASS |
| Region-specific M sensitivity | §3.6, §4.6 | region_specific_m_sensitivity.py | 36/36 pairs reversible; P(min)=36%; Japan rank 1–9 | Computational (interval + uniform-draw exploration) | Perturbation distribution artificial — stated | "conditional on the operational M … not a determinate fragility ranking" | PASS |
| Dropout elasticity | §3.5?, Table, P2 | sensitivity.csv | d most elastic lever in 9/9 regions | Structural (fitted-model elasticity) | Model-conditional | "most elastic lever" + model-conditional caveat | PASS |
| Historical drift | §3.8 | period comparison | margins shrink in N regions (P4) | Empirical (within fitted model) | Two-window, stationarity assumed | "supported in its weak form" | PASS |
| Talent concentration | §3.9, Figs 9–10 | dominant_strategy | effective regions fall; hits below baseline at γ thresholds | Model scenario (γ unidentified — stated) | γ, φ stylised; not causal | "model-dependent risk of reduced field-level diversity" | PASS |
| Collapse-rule non-activation | §3.9, Fig 10 caption | collapse_years.csv + full trajectory scan | 0/756 events; min trajectory T/M=20.7 | Empirical (of the simulation) | Horizon-limited | "never activated … outcomes do not depend on that assumption" | PASS |
| Methodological generalisability | §4.2 | — | pipeline parameterisation | Design property | Not external validity | "we do not claim the findings generalise … the machinery does" | PASS |
| M benchmark (intro premise iii/iv) | §1, §2.9 | — | M=k×c̄ definition | Operational construction | Not a validated survival threshold; not inside ODE dynamics | "classification condition … empirical question we do not claim to have answered" | PASS |

No claim remains that lacks a supporting output or a stated structural status.

# JOI Final Equation Render QC v3

- word/document.xml of JOI_MANUSCRIPT_FINAL_LOCK_v3.docx: 282 `<m:oMath>`
  blocks — all native OMML; no equations flattened or lost in this round's
  rebuild (script regenerated, not edited by hand).
- PDF render (LibreOffice): clean conversion, no U+FFFD replacement glyphs;
  Greek letters, sub/superscripts, fractions render. PASS.

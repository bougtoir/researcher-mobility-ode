# JOI Final Submission Checklist v3

## Submission files (docs/)
- [x] JOI_MANUSCRIPT_FINAL_LOCK_v3.docx
- [x] JOI_MANUSCRIPT_BLINDED_FINAL_LOCK_v3.docx
- [x] JOI_COVER_LETTER_FINAL_LOCK_v3.docx
- [x] JOI_TITLE_PAGE_FINAL_LOCK_v3.docx
- [x] JOI_HIGHLIGHTS_FINAL_LOCK_v3.docx
- [x] JOI_FIGURES_EDITABLE_FINAL_LOCK_v3.pptx

## Audit files (wip audit/)
- [x] JOI_FINAL_CLAIM_EVIDENCE_MATRIX.md
- [x] JOI_FINAL_THEORY_RECONCILIATION.md
- [x] JOI_FINAL_SEMANTIC_CODE_DELTA.md
- [x] JOI_FINAL_FIGURE_TABLE_QC_v3.md
- [x] JOI_FINAL_EQUATION_RENDER_QC_v3.md
- [x] JOI_FINAL_REFERENCE_QC_v3.md
- [x] JOI_FINAL_HOSTILE_REVIEW_v3.md
- [x] JOI_FINAL_SUBMISSION_CHECKLIST_v3.md
- [x] JOI_FINAL_HANDOFF_v3.md

## Packages (docs/)
- [x] JOI_SUBMISSION_FINAL_v3.zip (verified by extraction)
- [x] JOI_INDEPENDENT_AUDIT_FINAL_v3.zip (verified by extraction)

## Claim sweep on v3 manuscript markdown
Terms audited: minimum viable / viability boundary / collapse /
irreversib / early warning / sustainab / fragility / threshold /
evolutionary / reproduce its workforce / independent indicator /
generalise / policy. All remaining uses are either definitional,
negations, scenario-assumption attributions, or carry explicit caveats.
PASS.

# JOI Final Figure/Table QC v3

- check_manuscript.py on JOI_MANUSCRIPT_FINAL_LOCK_v3.docx: Figures 1–10,
  Tables 1–10 cited, first-mention order = numbering; PASS.
- Figure 10: caption now counterfactual + states zero crossings (matches
  plotted content: no crosses drawn since none occur). PASS.
- Table 2: "r (fitted)" disambiguation retained; OMML headers intact.
- Table 4: cf/proximity wording consistent with §3.4.
- Table 8: fixed-M T/M row matches ORIGIN_SENSITIVITY recompute.
- Table 9: scenario summary consistent with dominance outputs.
- Table 10: landscape section retained.
- Values in all tables/figures trace to canonical CSVs (n=623,176); no stale
  figures (v1/v2 leftovers absent; submission figure names use mvb).
- Supplement: no contradictions found; S11's common-multiplier scope is
  correctly qualified by the main-text region-specific analysis.
PASS.

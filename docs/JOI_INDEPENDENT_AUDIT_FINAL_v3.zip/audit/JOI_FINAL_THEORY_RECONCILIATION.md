# JOI Final Theory Reconciliation (v3)

## Repairs applied (prose only; no numeric changes)

1. **Introduction premises (iii)/(iv)** — previously asserted "a research
   system must exceed M to sustain its norms of production" and "below M the
   system can no longer reproduce its PI stock … path-dependent loss".
   Now: M is an operational benchmark from observed coauthor structure;
   sub-M is a classification condition; whether real communities stop
   reproducing, lose programmes, or fail irreversibly is stated as an
   empirical question the paper does not answer. Arthur path-dependence
   retained as intuition, not claim.
2. **§2.9** — "cannot produce work at the field's coauthor intensity" and
   "sufficient … condition for collapse" replaced by the five-way
   distinction (operational crossing / model-implied classification /
   observed production / actual failure / irreversibility). The
   terminology paragraph already separated dynamics/boundary/crossing/
   collapse/irreversibility and now matches.
3. **§4.5** — "evolutionary dead end" → "model-dependent risk of reduced
   field-level diversity", with the γ-unidentification caveat in-line.
4. **Figure 10 caption** — crosses now described counterfactually; caption
   states no region crosses M in any run (min 20.7, computed at build time),
   so the collapse rule never activates. Consistent with §3.9 text.
5. **Supplementary/alt text for Fig 10** — same counterfactual phrasing.
6. **§4.1 opening** — "the scale below which it can no longer reproduce its
   research workforce" → "an operational benchmark scale … below which, in
   model terms, it would be classified as sub-scale".

## Consistency sweep

Discussion and Conclusion use "monitoring diagnostic / model-implied
viability boundary / conditional on the operational M" throughout;
Introduction, §2.9, Results and Conclusion now tell one story: M is an
operational benchmark outside the ODE; crossing it is a classification,
not a demonstrated collapse; irreversibility is a scenario assumption only.

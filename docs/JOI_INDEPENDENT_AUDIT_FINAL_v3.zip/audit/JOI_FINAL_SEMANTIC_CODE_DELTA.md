# JOI Final Semantic Code Delta (v3)

Prose-only delta this round; scientific code unchanged except one display-side
addition (Figure 10 caption now computes the trajectory minimum from
`trajectories.csv` at build time — no pipeline change).

Bidirectional checks on the repaired claims:

- M construction: estimand k×c̄; units authors; denominator = works' author
  counts; M used only as comparison target — manuscript now says exactly
  this ("enters the model only as a comparison target"). MATCH.
- T/M: equilibrium T / M; monotone decreasing in s for M' = sM; ranking
  claims now conditional — code computes both common and region-specific
  variants; manuscript distinguishes algebraic vs independent-perturbation
  results. MATCH.
- Boundary proximity: cf scanned to drive T→M; proximity = |cf−1|; stated
  as closest-lever reading, not independent test. MATCH.
- Collapse rule: event-triggered r→0 switch in `dominant_strategy.py`;
  verified inactive over all timepoints (min T/M 20.74); manuscript claims
  exactly non-activation. MATCH.
- γ-dependence: field hit stock outcome varies with γ; γ unidentified —
  §4.5 now states this next to the softened phrase. MATCH.
- Policy levers: Table 10 model-conditional; no causal claim. MATCH.

No new inconsistency found. PASS.

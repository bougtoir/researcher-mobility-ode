# JOI Final Figure/Table Audit v4

- check_manuscript.py on JOI_MANUSCRIPT_FINAL_LOCK_v4.docx: Figures 1–10
  and Tables 1–10 cited, first-appearance order = numbering. PASS.
- Figure 10 caption explicitly states no region crossed M in any run and
  that no crosses appear; consistent with repaired §3.9 body text.
- Table 2/3/4/8/9/10 contents re-verified against canonical CSVs (see
  Table Render Audit v4); no value changed.
- Figures regenerated from the same canonical outputs; no stale v2/v3
  figure files in the package.
- Supplement: every referenced supplementary figure/table exists; main
  text carries all load-bearing measurement caveats, so no essential
  scientific claim lives only in the supplement.
PASS.

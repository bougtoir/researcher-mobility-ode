# JOI Final Hostile Review v4 (12 questions, on the actual v4 DOCX)

1. Does any sentence still imply crossing M changes the fitted ODE
   dynamics? — No. The two offending clauses are replaced; regression
   script finds 0 hard failures; remaining "switches off" language is
   explicitly attributed to the scenario's collapse rule. CLEAR.
2. Is M a sufficient/necessary condition for empirical collapse? —
   Explicitly denied in §4.6; §2.9 classification-only. CLEAR.
3. Irreversible collapse claimed without support? — Irreversibility
   labelled a property of the scenario rule, "not an empirical finding".
   CLEAR.
4. Operational definitions vs real-world constructs? — PI ("operational
   proxy … not a tenured group leader"), macro-region ("modelling
   assumption"), origin rules and M all now carry explicit operational
   framing. CLEAR.
5. PI recruitment capacity inferred too strongly? — §2.1 now states last
   authorship "stands in for group leadership rather than demonstrating
   it". CLEAR.
6. Macro-regions as validated systems? — §2.6 recast as modelling
   assumption; Huntington = starting heuristic only; §4.6 disclaims that
   regions carry distinct research programmes. CLEAR.
7. Structural invariances as empirical findings? — T-side invariance
   labelled structural/by-calibration; common-multiplier invariance
   labelled algebraic, not evidential. CLEAR.
8. Region-specific M uncertainty vs ranking strength? — Fully disclosed
   (36/36 reversible, conditional ranking) in §3.6, §4.6, abstract, cover
   letter. The claim is now exactly as strong as the evidence. CLEAR.
9. Policy implications beyond the model? — Table 10 model-conditional;
   §4.5 hypotheses not causal effects; institutional-level use explicitly
   unvalidated. CLEAR.
10. Cover letter consistency? — "I" voice; no collapse prediction,
    independent-test, irreversibility, causal or cross-field
    generalisation claims; matches v4 wording. CLEAR.
11. Genuine methodological contribution? — Main-text measurement audit +
    reproducible pipeline + explicit boundary semantics is a real
    informetrics contribution; editorial-taste risk noted, not a hold.
    CLEAR.
12. DOCX equations/tables readable? — 282 OMML blocks, PDF render clean,
    table headers render (OMML), landscape Table 10 legible. CLEAR.

Severity ledger: 0 critical, 0 major, 0 minor open. Residual risks:
editorial framing; M external validity (documented limitation).

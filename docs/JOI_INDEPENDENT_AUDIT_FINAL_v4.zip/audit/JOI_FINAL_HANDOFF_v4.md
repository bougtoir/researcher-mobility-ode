# JOI Final Handoff v4

- Final decision: **JOI CONDITIONAL SUBMIT** — only author-side
  administrative actions remain (names, affiliations, ORCID, COI, funding).
- Target journal: Journal of Informetrics.
- Branch: public `devin/20261104-joi-gate5`; wip `devin/1793781351-aiml-resubmission`.
- PR: https://github.com/bougtoir/researcher-mobility-ode/pull/1 (unmerged).
- Canonical cohort: n = 623,176. No numerical changes.
- Scientific changes (v3→v4, prose only): §4.6 boundary-semantics repair
  (feedback-stop and sufficient-condition clauses), §4.3 literature-link
  repair, §2.1 PI-as-proxy, §2.6 recruitment-pool-as-assumption, §3.9
  no-crossing wording, §4.4 institutional validity disclaimed, Conclusion
  model-conditional phrasing, "fragility ranking"→"proximity ranking".
- QC root cause: keyword-only paragraph-level sweep; clauses asserting
  dynamical effects of M were outside the trigger vocabulary. Fix:
  semantic_claim_regression.py now runs on the actual DOCX.
- Human actions: fill placeholders → merge PR #1 → Editorial Manager
  submission (subscription route).

# JOI Final Reference Audit v4

- 52 references; none added or removed in v4 (repairs were prose-only).
- Vancouver order verified on the v4 build: first-mention order = numbered
  list; no orphans (registry check at build time; check_manuscript PASS).
- Delta check on attachment points:
  - shaffer (minimum viable population): used only for the M-benchmark
    analogy, not as empirical validation of a survival threshold —
    consistent with the repaired §2.9/§4.6 wording.
  - arthur/nelson/dosi: cited for the path-dependence intuition and
    threshold concepts, explicitly "intuition", not proof of mechanism.
  - stephan (PI definition), huntington (initial partition heuristic,
    explicitly "documented starting heuristic"), katz (recruitment
    externality), mobility citations (thorn, appelt, franzoni): each
    attached to the construct it supports.
  - Historical-concentration examples cited as context, not as evidence
    for the ODE mechanism.
  - Policy instruments: no causal-effect citation overstated; Table 10
    remains model-conditional.
PASS.

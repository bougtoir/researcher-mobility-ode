# JOI QC Failure Root Cause (v4)

## Question
v3's theory-reconciliation audit reported the reconciliation complete, yet
independent review found three contradictory assertions in §§4.3 and 4.6.
Why did v3 QC miss them?

## Evidence examined
- v3 generated md (`JOI_MANUSCRIPT_FINAL_LOCK_v3.md`) vs generator source
  (`build_full_manuscript.py`): identical wording — not a stale build and
  not a source/DOCX divergence.
- The three offending sentences existed verbatim in the v3 build: they are
  inside one large §4.6 Limitations paragraph and one §4.3 sentence.
- v3's claim sweep grepped for trigger words ("collapse", "sustainab",
  "threshold", "reproduce its workforce", ...) on the manuscript text and
  required each *remaining use* to be definitional/negated/scenario-bound.
  The offending sentences passed that check because they sat inside
  paragraphs dominated by correct negations ("not an empirical finding",
  "could in principle rebuild"), and the sweep inspected at
  word-occurrence level, not per-clause assertion level. The clause
  "the viability boundary denotes the threshold at which the fitted
  feedback loop stops sustaining the pool" contains no trigger word from
  the list — "feedback" and "stops sustaining" were not in the vocabulary.
- The §4.3 sentence ("whose crossing makes the loss self-reinforcing
  rather than recoverable") was inherited from the v1 premise paragraph
  written before the boundary semantics were fixed; v2/v3 edits repaired
  the sentences around it but not this clause.

## Actual cause
Keyword-driven sweep with a fixed trigger vocabulary, applied at
paragraph level, inside long compound paragraphs that mixed valid
negations with invalid assertions. The audit operated on the correct
(final) build, so it was not a stale-document failure; it was a
semantic coverage failure — clauses asserting *dynamical* effects of M
(the fitted loop "stopping") were invisible to the trigger list.

Affected files: `scripts/build_full_manuscript.py` (source of the three
sentences), hence all generated v3 manuscript artifacts.

## Corrective action
- Repaired the three sentences (see JOI_FINAL_SEMANTIC_CLAIM_AUDIT_v4.md).
- Added `scripts/semantic_claim_regression.py`: extracts all visible text
  (paragraphs, table cells, captions, headers/footers, OMML runs) from the
  actual generated DOCX and runs claim-pattern rules, including the three
  known failure patterns as affirmative-claim tests (negations do not
  fire). Hard-fails on assertions, flags denials for review.

## Regression prevention
- The regression script is part of the build QC set; run it on every
  rebuilt DOCX alongside check_manuscript.py.
- Trigger vocabulary widened to dynamical-effect verbs ("stops", "switches
  off", "self-reinforcing", "sustaining").

## Final verification
`python3 scripts/semantic_claim_regression.py docs/JOI_MANUSCRIPT_FINAL_LOCK_v4.docx`
→ 0 hard failures, 8 REVIEW flags, each a legitimate negation or
scenario-assumption attribution (verified manually).

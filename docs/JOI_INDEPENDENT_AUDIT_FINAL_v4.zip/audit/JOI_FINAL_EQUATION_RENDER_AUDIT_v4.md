# JOI Final Equation Render Audit v4

- word/document.xml of JOI_MANUSCRIPT_FINAL_LOCK_v4.docx: 282 `<m:oMath>`
  blocks — all native OMML (Greek letters, sub/superscripts, fractions,
  numbered display equations).
- PDF render (LibreOffice, 45 pages): no U+FFFD replacement characters;
  Greek letters (α, β, γ, ε, ρ, τ, φ, Δ), subscripts (I_0, p_D, T/M) and
  equation numbering render correctly; cross-references "(Eq. n)" intact.
- Caption math symbols (M, γ, φ, τ) render in captions and figure text.
- Table header symbols render as OMML runs (see Table Render Audit v4).
PASS.

# JOI Final Table Render Audit v4

Method: compared canonical CSV → generation code → DOCX table XML →
LibreOffice PDF render (45 pp) for Tables 2, 3, 4, 8, 9, 10.

- Table 2: headers contain OMML math runs (T, M, r, T/M); plain-text
  extraction shows gaps but `word/document.xml` contains `<m:oMath>`
  blocks and the PDF renders all symbols. Values match
  equilibrium_summary.csv. "r (fitted)" disambiguation retained.
- Table 3: rate labels match RATE_LABELS/display names; fitted values
  match transition_rates.csv.
- Table 4: critical-factor labels and cf values match
  closest_point_of_no_return.csv (0.0025–0.0046).
- Table 8: origin/mobility/PI/missingness rows consistent with
  ORIGIN_SENSITIVITY/PI_SENSITIVITY CSVs; fixed-M T/M row matches recompute.
- Table 9: scenario summary consistent with dominance outputs.
- Table 10: landscape section retained in DOCX; PDF shows the rotated
  page; columns legible.
- PPTX: editable figure objects; no flattened tables.
Verdict: no missing mathematical headers; earlier "missing header" finding
was a plain-text-extraction artifact, not a render defect. PASS.

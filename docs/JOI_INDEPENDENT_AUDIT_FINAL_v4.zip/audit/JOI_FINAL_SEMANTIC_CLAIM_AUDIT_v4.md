# JOI Final Semantic Claim Audit v4

## Repairs applied (before/after)

| Section | Original wording | Revised wording | Reason | Evidence | Numbers changed |
|---|---|---|---|---|---|
| §4.6 | "the viability boundary denotes the threshold at which the fitted feedback loop stops sustaining the pool" | "the viability boundary is an operational comparison benchmark derived from observed coauthor structure: it does not alter the fitted ODE dynamics, and crossing it does not establish that the endogenous recruitment mechanism ceases to operate or that the community becomes unable to recover" | M is outside the ODE; feedback stops only under the external scenario rule | dominant_strategy.py (rule externally imposed); §2.9/§2.10 text | No |
| §4.6 | "Falling below M is a sufficient rather than necessary condition for collapse" | "a sufficient condition only for classification as sub-scale under the operational definition; it is neither an established necessary nor sufficient condition for empirical community collapse" | Unsupported sufficiency claim | 0 collapse events observed; no empirical crossing exists | No |
| §4.3 | "it does not specify a community-level state variable whose crossing makes the loss self-reinforcing rather than recoverable" | "it generally does not link observed career transitions to a community-level dynamical model and an explicitly defined operational scale benchmark" | Clause implied crossing changes dynamics; also over-strong novelty claim | Literature survey wording softened per instruction; no priority claim retained | No |
| §2.1 | "the population able to lead work and recruit" | "an operational proxy for the population able to lead work and recruit-last authorship stands in for group leadership rather than demonstrating it" | Last authorship ≠ demonstrated recruitment capacity | §6.1 requirement | No |
| §2.6 | "share funding systems … closely enough to be treated as one recruitment pool" | "treated as one recruitment pool under the modelling assumption that their AI/ML researchers share … closely enough for aggregate rates to be meaningful" | Homogeneity is a modelling assumption, not established fact; Huntington retained as documented starting heuristic only | §6.2 requirement | No |
| §3.9 | "source regions decline toward their thresholds, and each crossing of M switches off that region's PI-driven recruitment" | "source regions' margins narrow toward, but never reach, their thresholds within the horizon; were a crossing of M to occur it would switch off … a discrete model event that no run produces" | No crossing occurred in any run; prior wording implied crossings happen | 0/756 collapse events; min trajectory T/M 20.7 | No |
| §4.4 | "institutions that convert hit researchers into PIs … regenerate their own inflow" | "would, on the fitted mechanism, regenerate their own inflow … institutional-scale validity is unvalidated until an institutional calibration exercise is done" | Analysis is macro-region level; no institutional validation | §6.6 requirement | No |
| Conclusion | "exogenous entry is the binding lever everywhere" | "in the fitted model … exogenous entry is the binding lever everywhere at the observed scale" | Binding-lever claim is model- and scale-conditional (dropout binds under larger M) | region_specific_m proximity results | No |
| P3 statement | "fragility ranking" | "proximity ranking" / "defined boundary" | "Fragility" implies real-world fragility | Prompt trigger list | No |

## Full sweep
All paragraphs, captions, table cells, headers/footers of the v4 DOCX were
extracted and classified (A–I). Post-repair classification of every
claim-bearing sentence: no category-I (unsupported) assertion found;
remaining uses of trigger vocabulary are definitional (E), scenario (F),
model-implied (C) with explicit labelling, or hypotheses (G). The 12
required logical distinctions (§5.3 of the gate) verified point by point —
including affiliation≠relocation, last-author≠PI (now explicit),
M-crossing≠collapse (now explicit in §2.9 and §4.6), scenario rule≠ODE
(explicit), structural invariance≠empirical robustness (§3.6/§3.7),
common-multiplier≠independent-M (§3.6), institutional validity disclaimed
(§4.4).

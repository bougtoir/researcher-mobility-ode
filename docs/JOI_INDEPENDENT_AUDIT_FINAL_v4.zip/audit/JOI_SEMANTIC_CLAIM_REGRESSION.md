# JOI Semantic Claim Regression (v4)

## What it is
`scripts/semantic_claim_regression.py` — a lightweight tripwire that runs
on the generated DOCX (not the Markdown mirror):

1. Extracts every visible paragraph, table-cell text, caption, header and
   footer paragraph, including OMML `<m:t>` math text.
2. Splits into sentences.
3. Applies six claim-pattern rules; each rule pairs an affirmative-claim
   pattern with an "exoneration" pattern so a sentence that *denies* or
   scenario-bounds the claim is flagged for review, not failed.
4. Exit code 1 on any hard failure.

## Explicit tests for the three known v3 failures
- "M crossing stops the fitted feedback" → FAIL unless the sentence
  attributes the switch-off to the scenario's collapse rule or negates it.
- "M crossing is a sufficient/necessary condition for empirical collapse"
  → FAIL unless qualified to classification-only.
- "M crossing makes loss irreversible/self-reinforcing" → FAIL unless
  negated or scenario-bound.

## v4 results
- JOI_MANUSCRIPT_FINAL_LOCK_v4.docx: **0 hard failures, 8 review flags** —
  all confirmed negations or explicit scenario-rule attributions.
- check_manuscript.py: all mechanical checks passed.

## Limits
Pattern rules cannot prove semantic consistency; they trip on known
failure shapes. Manual hostile review (JOI_FINAL_HOSTILE_REVIEW_v4.md)
remains the primary check for novel assertion forms.

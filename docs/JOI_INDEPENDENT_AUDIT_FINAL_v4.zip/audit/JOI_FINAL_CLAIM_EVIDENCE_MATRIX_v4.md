# JOI Final Claim–Evidence Matrix v4

Same 11 claims as the v3 matrix (all PASS), with three v4 deltas:

| Claim | v4 status change |
|---|---|
| Viability boundary | Reclassified: explicitly an operational comparison benchmark outside the ODE (category E/C), not a dynamical threshold (fixed §4.6 wording) |
| Sub-M classification | Now "sufficient only for classification as sub-scale"; necessary/sufficiency for real collapse explicitly denied (category E) |
| Literature link (§4.3) | Novelty phrased as "generally does not link"; no absolute priority claim (category G → appropriately hedged claim) |

All other rows unchanged from JOI_FINAL_CLAIM_EVIDENCE_MATRIX.md (v3):
origin 0/54, PI 6 definitions with structural T-invariance, T/M one-scale,
boundary proximity closest-lever, region-specific M 36/36 reversible with
ranking declared conditional, dropout elasticity, weak-form P4,
talent-concentration scenario as model-consistent projection, collapse
non-activation 0/756, methodological generalisability as machinery not
findings.

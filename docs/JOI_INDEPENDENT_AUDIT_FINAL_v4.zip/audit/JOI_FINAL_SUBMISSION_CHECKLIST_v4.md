# JOI Final Submission Checklist v4

## Submission files (docs/)
- [x] JOI_MANUSCRIPT_FINAL_LOCK_v4.docx
- [x] JOI_MANUSCRIPT_BLINDED_FINAL_LOCK_v4.docx
- [x] JOI_COVER_LETTER_FINAL_LOCK_v4.docx
- [x] JOI_TITLE_PAGE_FINAL_LOCK_v4.docx
- [x] JOI_HIGHLIGHTS_FINAL_LOCK_v4.docx
- [x] JOI_FIGURES_EDITABLE_FINAL_LOCK_v4.pptx

## Audit files (wip audit/)
- [x] JOI_FINAL_SEMANTIC_CLAIM_AUDIT_v4.md
- [x] JOI_QC_FAILURE_ROOT_CAUSE.md
- [x] JOI_SEMANTIC_CLAIM_REGRESSION.md
- [x] JOI_FINAL_TABLE_RENDER_AUDIT_v4.md
- [x] JOI_FINAL_EQUATION_RENDER_AUDIT_v4.md
- [x] JOI_FINAL_CLAIM_EVIDENCE_MATRIX_v4.md
- [x] JOI_FINAL_REFERENCE_AUDIT_v4.md
- [x] JOI_FINAL_FIGURE_TABLE_AUDIT_v4.md
- [x] JOI_FINAL_HOSTILE_REVIEW_v4.md
- [x] JOI_FINAL_SUBMISSION_CHECKLIST_v4.md
- [x] JOI_FINAL_HANDOFF_v4.md

## Packages
- [x] JOI_SUBMISSION_FINAL_v4.zip — verified by extraction
- [x] JOI_INDEPENDENT_AUDIT_FINAL_v4.zip — verified by extraction

## Format
TNR 12pt body / 10pt captions, black text, native OMML, editable PPTX,
no residual Markdown asterisks, abstract ≤250 words, highlights ≤85 chars.
